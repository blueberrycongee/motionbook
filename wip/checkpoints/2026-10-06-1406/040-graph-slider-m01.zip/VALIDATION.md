# Run and validation

This is a source-only work-in-progress checkpoint. It is not approved for the final gallery and has no final preview media yet.

Run `npm start` and open port 8040 in a permitted browser. Move across the chart to scrub its time. The pointer position controls distance along the drawn curve. Arrow keys move one minute; Home and End select either endpoint. Replay restores the recorded sequence. Reduced motion starts paused.

All 552 native source frames and three full-size reference states were inspected. The source itself holds the same graph, marker and tooltip at the beginning and end; no extra return bridge is needed. The replay records every original timestamp. Marker, guide and tooltip positions are retained separately because the footage shows small relative offsets during motion.

The current path is independently drawn from observed anchors. Native marker/guide positions and all 61 time labels were measured. Twenty ambiguous OCR hour glyphs were manually checked against enlarged source crops. The initial implementation still needs geometric fitting, native-size text/gradient/pointer refinement, complete source/replica comparison, final GIF/MP4 export and independent review.

`npm test` exercises timestamp selection, the natural loop, path-distance sampling, pointer and keyboard clamping, interrupted replay, touch capture and reduced motion. DOM checks use a stub. For an offline still, install the declared Sharp dependency and run `node render.cjs <seconds> <output.png>`.

Browser execution has not been validated. Previously denied local browser launch and local-site access remain respected. Offline SVG rasterization and mocked DOM checks are recorded separately from browser testing.
