(function(root,factory){if(typeof module==='object')module.exports=factory(require('./motion-data.js'),require('./state.js'));else root.Scene=factory(root.SchedulerMotion,root.SchedulerState);})(this,function(Motion,State){
'use strict';
const W=1080,H=698,FPS=60,DURATION=32,clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v)),ease=v=>{v=clamp(v);return v*v*(3-2*v);};
const INPUT_EVENTS=[[0,''],[143,'m'],[148,'me'],[156,'mee'],[173,'meet'],[208,'meeti'],[219,'meetin'],[229,'meeting'],[244,'meeting '],[248,'meeting w'],[253,'meeting wi'],[262,'meeting wit'],[278,'meeting with'],[285,'meeting with '],[299,'meeting with h'],[308,'meeting with hi'],[354,'meeting with h'],[364,'meeting with '],[394,'meeting with j'],[400,'meeting with ji'],[411,'meeting with jil'],[424,'meeting with jill'],[429,'meeting with jille'],[447,'meeting with jilles'],[483,'meeting with jilles '],[488,'meeting with jilles a'],[502,'meeting with jilles an'],[512,'meeting with jilles and'],[518,'meeting with jilles and '],[575,'meeting with jilles and h'],[584,'meeting with jilles and ha'],[594,'meeting with jilles and har'],[604,'meeting with jilles and hars'],[612,'meeting with jilles and harsh'],[620,'meeting with jilles and harshi'],[624,'meeting with jilles and harshil']];
function timeline(time){
 let t=((time%DURATION)+DURATION)%DURATION,opacity=1;if(t>=29.4&&t<30.2)opacity=1-ease((t-29.4)/.8);if(t>=30.2){opacity=ease((t-30.2)/.8);t=0;}
 const n=Math.min(1692,Math.floor(t*60+.00001)),r=Motion.rows[n],s=State.initial();s.recorded=true;s.frame=n;s.time=t;s.opacity=opacity;s.motion=r;s.prompt=INPUT_EVENTS.reduce((v,e)=>e[0]<=n?e[1]:v,'');s.calendarAlpha=ease((n-140)/15);s.suggestionsAlpha=1-ease((n-144)/13);s.summaryAlpha=ease((n-142)/13);s.duration=n>=898?45:30;s.guests=[];s.start=n>=911?660:540;
 if(n>=312&&n<386){s.guests=[{id:'hideyuki',query:'hi',name:n>=348?'Hideyuki Tak...':'Hi',resolved:n>=348,alpha:n<354?ease((n-311)/12):1-ease((n-354)/28)}];}
 if(n>=402){const q=s.prompt.match(/with\s+(\w+)/)?.[1]||'ji';s.guests.push({id:'jilles',query:q,name:n>=474?'Jilles':q[0].toUpperCase()+q.slice(1),resolved:n>=474,alpha:ease((n-401)/13)});}
 if(n>=584){const q=s.prompt.match(/and\s+(\w+)/)?.[1]||'ha';s.guests.push({id:'harshil',query:q,name:n>=644?'Harshil':q[0].toUpperCase()+q.slice(1),resolved:n>=644,alpha:ease((n-583)/13)});}
 s.loading=(n>=312&&n<407)||(n>=402&&n<501)||(n>=584&&n<689);s.checking=s.loading?1:0;s.summaryReady=!s.loading;s.conflict=n>=1181&&n<=1312;s.conflictAlpha=n<1181?0:n<1304?ease((n-1180)/6):1-ease((n-1304)/9);s.dragging=n>=1026&&n<1418;
 if(n>=1028&&n<1418&&r.slot_bbox){const b=r.slot_bbox;s.start=clamp(Math.round((540+(b[0]+16-393)/52.7*60)/15)*15,540,1035);s.rawStart=s.start;}
 s.start=r.summary_start??s.start;s.rawStart=s.start;
 s.keyHint=n>=238&&n<345||n>=481&&n<575?'space':n>=351&&n<417?'backspace':'';return s;
}
function model(s){
 const present=!!s.prompt.trim(),guestCount=s.guests.length,loading=s.recorded?s.loading:!State.ready(s)&&present,conflict=s.recorded?s.conflict:State.conflict(s),baseRows=1+guestCount;
 let summaryH=126+(loading||conflict?30:0),summaryY=268+guestCount*51,card=[199,40,689,summaryY+summaryH+20];
 if(!present)card[3]=243;
 if(s.motion){card=s.motion.card.slice();const h=card[3]/(card[2]/689),n=s.frame;
  if(n>=312&&n<402){summaryY=268+clamp(h-445,0,51);summaryH=Math.max(126,h-summaryY-20);}
  else if(n>=402&&n<501){summaryY=268+clamp(h-445,0,51);summaryH=Math.max(126,h-summaryY-20);}
  else if(n>=501&&n<584){summaryY=319;summaryH=Math.max(126,h-summaryY-20);}
  else if(n>=584&&n<689){summaryY=319+clamp((h-466)*51/81,0,51);summaryH=Math.max(126,h-summaryY-20);}
  else if(n>=689){summaryY=370;summaryH=Math.max(126,h-summaryY-20);}
 }
 if(s.motion?.panel){summaryY=s.motion.panel[0];summaryH=s.motion.panel[1];}
 return{card,scale:card[2]/689,present,guestCount,loading,conflict,summaryY,summaryH,rows:baseRows,freeY:summaryY-27};
}
function rr(c,x,y,w,h,r,fill,stroke){c.beginPath();c.roundRect(x,y,w,h,r);if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=1;c.stroke();}}
function txt(c,v,x,y,size=14,color='#222',weight=400,align='left'){c.save();c.font=`${weight} ${size}px "Replica Sans"`;c.fillStyle=color;c.textAlign=align;c.textBaseline='alphabetic';c.fillText(v,x,y);c.restore();}
function line(c,x,y,X,Y,color,width=1){c.beginPath();c.moveTo(x,y);c.lineTo(X,Y);c.strokeStyle=color;c.lineWidth=width;c.stroke();}
function icon(c,type,x,y,color='#7c7c7f',size=1){c.save();c.translate(x,y);c.scale(size,size);c.lineWidth=1.7;c.lineCap='round';c.lineJoin='round';c.strokeStyle=color;c.fillStyle=color;c.beginPath();if(type==='calendar'){c.roundRect(-8,-7,15,14,2);c.moveTo(-8,-3);c.lineTo(7,-3);c.stroke();for(let a=-4;a<=3;a+=3)for(let b=0;b<=4;b+=3)c.fillRect(a,b,1.5,1.5);c.beginPath();c.arc(7,6,4,0,7);c.fillStyle='#f5f8ff';c.fill();c.stroke();line(c,5,6,9,6,color,1);line(c,7,4,7,8,color,1);}else if(type==='return'){c.moveTo(6,-5);c.lineTo(6,2);c.lineTo(-6,2);c.moveTo(-2,-2);c.lineTo(-6,2);c.lineTo(-2,6);c.stroke();}else if(type==='video'){c.roundRect(-8,-5,10,11,2);c.fill();c.beginPath();c.moveTo(3,-3);c.lineTo(9,-6);c.lineTo(9,6);c.lineTo(3,3);c.fill();}else if(type==='plus'||type==='minus'){line(c,-5,0,5,0,color,1.6);if(type==='plus')line(c,0,-5,0,5,color,1.6);}else if(type==='left'||type==='right'){const q=type==='left'?1:-1;c.moveTo(q*2,-5);c.lineTo(-q*3,0);c.lineTo(q*2,5);c.stroke();}else if(type==='info'){c.arc(0,0,6,0,7);c.fill();txt(c,'i',0,4,10,'#fff',600,'center');}else if(type==='sparkle'){c.moveTo(0,-7);c.quadraticCurveTo(1,-1,7,0);c.quadraticCurveTo(1,1,0,7);c.quadraticCurveTo(-1,1,-7,0);c.quadraticCurveTo(-1,-1,0,-7);c.fill();}else if(type==='check'){c.moveTo(-5,0);c.lineTo(-1,4);c.lineTo(6,-5);c.stroke();}c.restore();}
function portrait(c,id,x,y,size){
 c.save();c.translate(x,y);c.scale(size/32,size/32);c.beginPath();c.roundRect(0,0,32,32,6);c.clip();
 if(id==='hideyuki'){rr(c,0,0,32,32,6,'#eed1f5');txt(c,'H',16,21,14,'#b664c5',600,'center');c.restore();return;}
 const bg=c.createLinearGradient(0,0,32,32);bg.addColorStop(0,id==='you'?'#b7a075':id==='jilles'?'#ffffff':'#c9d1ca');bg.addColorStop(1,id==='you'?'#655c4c':id==='jilles'?'#fafbfd':'#aab8ba');c.fillStyle=bg;c.fillRect(0,0,32,32);
 if(id==='you'){c.fillStyle='#ddd4ad';c.fillRect(0,0,6,32);line(c,0,9,32,9,'#776957',1);line(c,28,0,28,32,'#443e34',2);}
 if(id==='harshil'){c.fillStyle='#e5e6db';c.fillRect(0,6,32,7);line(c,0,13,32,13,'#83918b',1);line(c,0,16,32,16,'#657a77',.8);line(c,3,0,3,22,'#b0b9b0',.8);}
 const cx=id==='you'?17:17,cy=id==='you'?14:id==='jilles'?13:9,rx=id==='you'?7.4:id==='jilles'?4.7:3.4,ry=id==='you'?9.6:id==='jilles'?6.9:4.4;
 const shirt=c.createLinearGradient(6,20,29,33);shirt.addColorStop(0,id==='jilles'?'#8fa6c2':'#283a46');shirt.addColorStop(.55,id==='jilles'?'#bcc9d8':'#142e3b');shirt.addColorStop(1,id==='jilles'?'#6f89a4':'#344752');c.fillStyle=shirt;c.beginPath();c.moveTo(cx-rx*.65,cy+ry*.8);c.quadraticCurveTo(cx-rx*1.8,cy+ry+3,id==='harshil'?9:2,32);c.lineTo(id==='harshil'?25:32,32);c.quadraticCurveTo(cx+rx*1.8,cy+ry+3,cx+rx*.65,cy+ry*.8);c.fill();
 const skin=c.createRadialGradient(cx-rx*.35,cy-ry*.3,.5,cx,cy,ry);skin.addColorStop(0,id==='you'?'#c48d65':'#e5bea0');skin.addColorStop(.7,id==='you'?'#a96d49':'#c79779');skin.addColorStop(1,id==='you'?'#764b35':'#92705d');c.fillStyle=skin;c.fillRect(cx-rx*.35,cy+ry*.5,rx*.7,ry*.7);c.beginPath();c.ellipse(cx,cy,rx,ry,0,0,7);c.fill();
 if(id==='you'){c.fillStyle='#292522';c.beginPath();c.moveTo(cx-rx,cy-1);c.bezierCurveTo(cx-rx-1,cy-ry-4,cx+rx+1,cy-ry-4,cx+rx,cy-1);c.lineTo(cx+rx-2,cy-4);c.quadraticCurveTo(cx,cy-8,cx-rx+2,cy-3);c.fill();}
 if(id==='harshil'){c.fillStyle='#243532';c.beginPath();c.ellipse(cx,cy-3.8,4.2,2.2,0,0,7);c.fill();c.fillRect(cx-2,cy-3,7,1.3);}
 const eyes=cy-1;line(c,cx-rx*.63,eyes,cx-rx*.22,eyes,'#46372d',.75);line(c,cx+rx*.2,eyes,cx+rx*.65,eyes,'#46372d',.75);line(c,cx,cy,cx-.7,cy+ry*.3,'#97694f',.65);line(c,cx-rx*.34,cy+ry*.57,cx+rx*.35,cy+ry*.55,'#764b39',.7);
 if(id!=='harshil'){c.strokeStyle=id==='you'?'rgba(60,42,31,.85)':'rgba(103,86,74,.8)';c.lineWidth=id==='you'?2.3:1.7;c.beginPath();c.ellipse(cx,cy+ry*.1,rx*.78,ry*.83,0,.05,Math.PI-.05);c.stroke();}
 line(c,cx-1,cy+ry+3,cx,32,id==='jilles'?'#728da7':'#45535a',.6);line(c,cx-5,cy+ry+6,cx-8,31,'rgba(245,248,251,.25)',.7);line(c,cx+5,cy+ry+5,cx+8,31,'rgba(0,0,0,.13)',.8);
 for(let j=0;j<85;j++){const px=(j*17.37)%32,py=(j*11.73)%32;c.fillStyle=j%2?'rgba(255,255,255,.045)':'rgba(0,0,0,.035)';c.fillRect(px,py,.65,.6);}c.restore();
}
function guestAvatar(c,g,x,y,size){if(g.resolved)portrait(c,g.id,x,y,size);else{const colors=g.id==='harshil'?['#ffe3eb','#db7195']:g.query.length>3?['#f3d5ff','#b951e1']:['#dcf7e9','#6bb598'];rr(c,x,y,size,size,6,colors[0]);txt(c,g.name[0],x+size/2,y+size*.68,size*.42,colors[1],600,'center');}}
function browserChrome(c,s,m){
 if(!s.recorded||s.frame>110)return;const a=m.card[2]/375,x=m.card[0]-352*a,y=m.card[1]-128.644*a;c.save();c.translate(x,y);c.scale(a,a);const g=c.createLinearGradient(0,0,1080,18);g.addColorStop(0,'#908c8b');g.addColorStop(.6,'#8e90b7');g.addColorStop(1,'#444765');c.fillStyle=g;c.fillRect(0,0,1080,19);txt(c,'●   Chrome    File    Edit    View    History    Bookmarks    Profiles    Tab    Window    Help',12,12,8,'#fff',500);txt(c,'▣     Growth Team Sync · 10:00 PM      ◇     ◉       Tue 29 Sep  6:06:42 PM',714,12,8,'#fff',400);c.fillStyle='#f1e3d2';c.fillRect(0,19,1080,28);c.fillStyle='#eeebea';c.fillRect(0,47,1080,28);for(let i=0;i<3;i++)rr(c,9+i*11,28,7,7,4,['#e6d3cb','#e5dbc7','#d5dccb'][i]);rr(c,192,21,183,27,9,'#fbf9f7');txt(c,'◉   Santosh Kumar – Chat',86,36,8,'#4c4c4c');txt(c,'Google',247,36,8,'#282828');txt(c,'×',360,36,10,'#333');txt(c,'＋',381,36,10,'#333');txt(c,'‹    ›    ↻',10,63,12,'#9c9c9c');rr(c,77,50,842,20,10,'#e5e2e0');txt(c,'☷   google.com/?zx=1790685374609',83,63,9,'#444');txt(c,'☆     ◇    ☐    ⋮',910,63,10,'#929292');rr(c,1001,50,50,20,11,'#f0d5be');txt(c,'Work',1018,63,9,'#777');c.restore();
}
function promptLine(c,s){
 if(!s.prompt){txt(c,'Coffee with Developer Friday at 10am for 30 min',74,45,18.3,'#b7b7b7',500);return;}
 let x=74;const spans=s.prompt.split(/(hi\b|jilles\b|harshil\b)/i);c.font='600 18.3px "Replica Sans"';for(const span of spans){const highlighted=/^(hi|jilles|harshil)$/i.test(span),w=c.measureText(span).width;if(highlighted)rr(c,x-1,27,w+2,23,2,'#e1e6ff');txt(c,span,x,45,18.3,highlighted?'#3c4bad':'#202326',600);x+=w;}
 if(!s.recorded||s.frame<800){line(c,x+2,25,x+2,49,'#3579d9',1);}
}
function suggestions(c,s){const a=s.suggestionsAlpha??(!s.prompt?1:0);if(a<=0)return;c.save();c.globalAlpha*=a;txt(c,'Try one',22,107,13,'#b7b7b7',500);const values=[['Sync with ',['Developer','#3e50b2'],' and ',['Bengaluru','#3e50b2'],' ',['tomorrow','#6c28b1'],' ',['afternoon','#98612b']],['Coffee with ',['Developer','#3e50b2'],' ',['Friday','#6c28b1'],' at ',['10am','#98612b'],' for ',['30 min','#55866e']],['Focus time ',['tomorrow','#6c28b1'],' ',['morning','#98612b'],' for ',['2h','#55866e']]];for(let i=0;i<3;i++){const y=140+i*39;icon(c,'sparkle',31,y-5,'#dfc260',.85);let x=50;for(const v of values[i]){const str=Array.isArray(v)?v[0]:v,color=Array.isArray(v)?v[1]:'#272727';txt(c,str,x,y,16,color,600);c.font='600 16px "Replica Sans"';x+=c.measureText(str).width;}}c.restore();}
function calendar(c,s,m){
 const alpha=s.calendarAlpha??(m.present?1:0);if(alpha<=0)return;c.save();c.globalAlpha*=alpha;const shift=s.recorded?-8*(1-alpha):0;c.translate(0,shift);txt(c,State.dateParts(s).heading,21,116,16,'#272727',600);txt(c,State.dateParts(s).short,106,116,16,'#b4b4b4');for(const [x,type]of[[624,'left'],[655,'right']]){rr(c,x-14,96,28,28,14,'#f4f4f4');icon(c,type,x,110,'#848484');}
 for(let j=0;j<10;j++)txt(c,['9','10','11','12','1','2','3','4','5','6'][j],193+j*52.7,153,12,'#bcbcbc',400,'center');
 const guests=[{id:'you',name:'You',resolved:true,alpha:1},...s.guests];for(let i=0;i<guests.length;i++){const g=guests[i],y=165+i*51;c.save();c.globalAlpha*=g.alpha??1;rr(c,193,y,475,41,11,'#f9f9f9','#ededed');for(let j=1;j<9;j++)line(c,193+j*52.7,y,193+j*52.7,y+41,'#e8e8e8');if(i===0)rr(c,378,y+5,92,32,7,s.motion?.busy_rgb?`rgb(${s.motion.busy_rgb.join(',')})`:m.conflict?'#f0b9c7':'#dcdcdc');if(i===0)portrait(c,'you',21,y+5,30);else guestAvatar(c,g,21,y+5,30);txt(c,g.name,61,y+18,14.5,'#262626',600);txt(c,i===0?'Kolkata':g.resolved?(State.PEOPLE[g.id]?.email||'Available'):'Looking up...',61,y+36,12.5,'#bcbcbc');c.restore();}
 c.restore();let box=s.motion?.slot_bbox;
 if(!s.recorded&&State.ready(s)){const width=s.duration/60*52.7+(s.dragging?32:0);box=[m.card[0]+(193+(s.start-540)/60*52.7-(s.dragging?16:0))*m.scale,m.card[1]+161*m.scale,width*m.scale,(50+s.guests.length*51)*m.scale];}
 if(box){const [x,y,w,h]=box,local=[(x-m.card[0])/m.scale,(y-m.card[1])/m.scale,w/m.scale,h/m.scale];c.save();c.globalAlpha*=s.motion?.slotAlpha??1;c.shadowColor=m.conflict?'rgba(213,68,109,.12)':'rgba(79,161,115,.12)';c.shadowBlur=s.dragging?10:2;const measured=s.motion?.slot_rgb,fill=measured?`rgba(${measured.join(',')},${s.motion.slot_fill_alpha})`:m.conflict?'rgba(218,88,122,.16)':'rgba(85,180,131,.13)';rr(c,local[0]+1,local[1]+1,local[2]-2,local[3]-2,10,fill);c.shadowBlur=0;c.strokeStyle=measured?`rgb(${measured.join(',')})`:m.conflict?'#cf6483':'#7cbd9a';c.lineWidth=1.6;c.stroke();c.restore();if(s.dragging&&!s.recorded){const text=State.formatTime(s.rawStart),w=Math.max(70,text.length*7.1+15),x=local[0]+local[2]/2;rr(c,x-w/2,130,w,23,12,m.conflict?'#d9557c':'#64be8e');txt(c,text,x,146,12,'#fff',600,'center');}}
 if(s.recorded)recordedTooltip(c,s,m);
 c.save();c.globalAlpha*=alpha;const y=m.freeY;if(m.loading)txt(c,'Checking calendars...',21,y,13,'#999');else{icon(c,'sparkle',29,y-5,'#dbc461',.7);txt(c,s.guests.length?"Everyone's free at":"You're free at",42,y,13.2,'#8a8a8a',500);let x=s.guests.length?164:132;for(const minute of State.suggestions(s)){const label=State.formatTime(minute),w=label.length*7.2+30,pill=s.motion?.selected_chip,center=m.card[0]+(x+w/2)*m.scale,selected=s.recorded?!!(pill&&center>pill.bbox[0]&&center<pill.bbox[0]+pill.bbox[2]):s.start===minute;rr(c,x,y-20,w,34,18,selected?(pill?`rgb(${pill.rgb.join(',')})`:'#c5f4e0'):'#fdfdfd',selected?'#b8ead2':'#f0f0f0');txt(c,label,x+w/2,y+2,14,selected?'#4c896b':'#979797',selected?600:400,'center');x+=w+8;}}c.restore();
}
// Recorded glyph transitions are separate from the live scheduling model.
function textTrack(events,n){let i=0;for(let j=1;j<events.length;j++){if(events[j][0]>n)break;i=j;}return{current:events[i][1],previous:events[Math.max(0,i-1)][1],age:n-events[i][0]};}
function rollingText(c,oldText,newText,p,x,y,size,color,weight=500,align='left',travel=4,softness=.7){
 p=clamp(p);if(p>=1||oldText===newText){txt(c,newText,x,y,size,color,weight,align);return;}
 c.save();c.font=`${weight} ${size}px "Replica Sans"`;const ow=c.measureText(oldText).width,nw=c.measureText(newText).width,w=ow+(nw-ow)*p,origin=align==='center'?x-w/2:x;
 const oldChars=Array.from(oldText),newChars=Array.from(newText),count=Math.max(oldChars.length,newChars.length);let ox=0,nx=0;
 for(let i=0;i<count;i++){const a=oldChars[i]||'',b=newChars[i]||'',xx=origin+ox+(nx-ox)*p;
  if(a===b)txt(c,a,xx,y,size,color,weight);else{
   if(a){c.save();c.globalAlpha*=1-p;c.filter=`blur(${softness*p}px)`;txt(c,a,xx,y-travel*p,size,color,weight);c.restore();}
   if(b){c.save();c.globalAlpha*=p;c.filter=`blur(${softness*(1-p)}px)`;txt(c,b,xx,y+travel*(1-p),size,color,weight);c.restore();}
  }
  ox=c.measureText(oldChars.slice(0,i+1).join('')).width;nx=c.measureText(newChars.slice(0,i+1).join('')).width;
 }
 c.restore();
}
function recordedTooltip(c,s,m){
 const z=s.motion?.tooltip;if(!z)return;const [X,Y,W,H]=z.bbox,x=(X-m.card[0])/m.scale,y=(Y-m.card[1])/m.scale,w=W/m.scale,h=H/m.scale;
 rr(c,x,y,w,h,h/2,`rgb(${z.rgb.join(',')})`);const track=textTrack(Motion.tooltip_events,s.frame),q=ease((track.age+1.75)/3.5),size=13.2*Math.min(1,h/22.5);
 c.save();c.globalAlpha*=z.ink_alpha;rollingText(c,State.formatTime(track.previous),State.formatTime(track.current),q,x+w/2+.35,y+h/2+size*.325,size,'#fff',700,'center',.7,.25);c.restore();
}
function maskedTime(c,field,x,y){
 const label=State.formatTime(field.value),colon=label.indexOf(':');c.save();c.font='500 13.7px "Replica Sans"';let advance=0;
 for(let i=0;i<label.length;i++){
  const ch=label[i],digit=/\d/.test(ch),width=digit?7:c.measureText(ch).width,group=i<colon?'hour':i>colon&&i<colon+3?'minute':i>=label.length-2?'period':null;c.save();if(group){c.globalAlpha*=field[group+'_alpha']??1;c.filter=`blur(${field[group+'_blur']??0}px)`;}
  if(digit){c.translate(x+advance+width/2,y);c.scale(.82,1);txt(c,ch,0,0,13.7,'#828282',500,'center');}else txt(c,ch,x+advance,y,13.7,'#828282',500);c.restore();advance+=width;
 }
 c.restore();return advance;
}
function summaryCaption(c,s,m,y){
 if(m.loading){txt(c,'Pick a time',55,y,13.7,'#828282',500);return;}
 const date=State.dateParts(s).long+' · ',tail=' · '+(s.guests.length?s.guests.length+' guest'+(s.guests.length>1?'s':''):'Just you');
 const fields=s.motion?.summary_text||{start:{value:s.start},end:{value:s.start+s.duration}};
 c.save();c.font='500 13.7px "Replica Sans"';txt(c,date,55,y,13.7,'#828282',500);let x=55+c.measureText(date).width;x+=maskedTime(c,fields.start,x,y);txt(c,' – ',x,y,13.7,'#828282',500);x+=c.measureText(' – ').width;x+=maskedTime(c,fields.end,x,y);txt(c,tail,x,y,13.7,'#828282',500);c.restore();
}
function summary(c,s,m){
 const a=s.summaryAlpha??(m.present?1:0);if(a<=0)return;c.save();c.globalAlpha*=a;const y=m.summaryY;rr(c,21,y,647,m.summaryH,20,'#fdfdfd','#ededed');rr(c,36,y+16,5,44,3,s.motion?.stripe_rgb?`rgb(${s.motion.stripe_rgb.join(',')})`:m.loading?'#cecece':m.conflict?'#d65b7d':'#5ec290');txt(c,State.title(s),56,y+36,16.5,'#262626',700);
 c.save();c.translate(56,0);c.scale(1.045,1);c.translate(-55,0);summaryCaption(c,s,m,y+54);c.restore();
 s.guests.forEach((g,i)=>guestAvatar(c,g,617-(s.guests.length-1-i)*20,y+23,30));
 for(const[x,type,fill]of[[55,'video','#e5edff'],[101,'minus','#fff'],[237,'plus','#fff']]){rr(c,x-19,y+73,38,38,19,fill,'#ededed');icon(c,type,x,y+92,type==='video'?(s.video===false?'#888':'#638ae1'):'#262626');}
 rr(c,129,y+73,82,38,19,'#fff','#ededed');txt(c,s.duration+' min',170,y+98,15,'#171717',600,'center');rr(c,556,y+73,96,38,19,m.loading?'#fff':'#4b86ef',m.loading?'#ededed':undefined);txt(c,s.booked?'Booked':'Book',594,y+98,16,m.loading?'#aaa':'#fff',600,'center');icon(c,s.booked?'check':'return',626,y+93,m.loading?'#aaa':'#fff',.8);
 if(m.loading||m.conflict){c.save();if(s.recorded&&m.conflict){c.globalAlpha*=s.conflictAlpha;c.filter=`blur(${(1-s.conflictAlpha)*3}px)`;}const color=m.conflict?'#9a612c':'#999';icon(c,'info',37,y+135,color,.9);const g=s.guests.find(g=>!g.resolved);txt(c,m.conflict?'You already have something then':g?'Looking up '+g.name+'...':'Checking calendars...',51,y+140,13,color,500);c.restore();}
 c.restore();
}
function cursor(c,s){if(!s.motion?.pointer)return;const ring=s.motion.click_ring;if(ring){c.save();c.beginPath();c.arc(ring.x,ring.y,Math.max(1,ring.radius-1.5),0,Math.PI*2);c.strokeStyle=`rgb(${ring.rgb.join(',')})`;c.lineWidth=2.5;c.stroke();c.restore();}const p=s.motion.pointer,[x,y,w,h]=p;c.save();c.translate(x-2,y-2);c.shadowColor='rgba(0,0,0,.24)';c.shadowBlur=4;c.shadowOffsetY=3;c.strokeStyle='#fff';c.lineJoin='round';c.lineWidth=5;c.fillStyle='#090909';if(w<=13){c.shadowBlur=0;c.strokeStyle='#171717';c.lineWidth=1.8;c.beginPath();c.moveTo(6,3);c.lineTo(6,h-2);c.moveTo(0,0);c.quadraticCurveTo(6,0,6,5);c.quadraticCurveTo(6,0,12,0);c.moveTo(0,h);c.quadraticCurveTo(6,h,6,h-5);c.quadraticCurveTo(6,h,12,h);c.stroke();}else{const scale=h/34;c.scale(scale,scale);c.beginPath();c.moveTo(0,0);c.lineTo(0,26);c.lineTo(7,20);c.lineTo(12,32);c.lineTo(17,30);c.lineTo(12,19);c.lineTo(22,18);c.closePath();c.stroke();c.fill();}c.restore();}
function draw(c,time,assets={},manual){
 const s=manual||timeline(time),m=model(s);c.clearRect(0,0,W,H);c.fillStyle='#fff';c.fillRect(0,0,W,H);c.save();c.globalAlpha=s.opacity??1;browserChrome(c,s,m);c.save();c.translate(m.card[0],m.card[1]);c.scale(m.scale,m.scale);const h=m.card[3]/m.scale;c.save();c.shadowColor='rgba(0,0,0,.37)';c.shadowBlur=30;c.shadowOffsetY=16;rr(c,0,0,689,h,28,'#fdfdfd');c.restore();c.save();c.shadowColor='rgba(0,0,0,.09)';c.shadowBlur=3;c.shadowOffsetY=2;rr(c,0,0,689,h,28,'#fdfdfd');c.restore();rr(c,0,0,689,h,28,undefined,'#e4e4e4');line(c,0,78,689,78,'#eeeeee');rr(c,21,20,39,39,11,'#e9effd','#cbd6ec');icon(c,'calendar',41,40,'#6385d1');promptLine(c,s);if(m.present){rr(c,641,25,27,27,7,m.loading?'#f6f6f6':'#edf3fd');icon(c,'return',655,39,m.loading?'#b3b3b3':'#7191ce',.8);}suggestions(c,s);calendar(c,s,m);summary(c,s,m);c.restore();cursor(c,s);if(s.keyHint){const w=s.keyHint==='space'?96:58,x=(W-w)/2;rr(c,x,617,w,48,11,'rgba(40,40,40,.72)');if(s.keyHint==='space')txt(c,'space',W/2,648,20,'#fff',500,'center');else{rr(c,531,635,16,16,3,undefined,'#fff');line(c,535,639,543,647,'#fff',1.5);line(c,543,639,535,647,'#fff',1.5);}}c.restore();return m;
}
function hitTargets(s){const m=model(s),out=[],add=(label,x,y,w,h,action,disabled=false)=>out.push({label,x:m.card[0]+x*m.scale,y:m.card[1]+y*m.scale,w:w*m.scale,h:h*m.scale,action,disabled});if(!m.present){for(let i=0;i<3;i++)add('Try example '+(i+1),20,119+i*39,648,35,{type:'example',index:i});return out;}add('Previous day',609,95,30,30,{type:'day',delta:-1});add('Next day',640,95,30,30,{type:'day',delta:1});let x=s.guests.length?164:132;for(const minute of State.suggestions(s)){const label=State.formatTime(minute),w=label.length*7.2+30;add(label,x,m.freeY-20,w,34,{type:'time',minutes:minute});x+=w+8;}add('Toggle video meeting',36,m.summaryY+73,38,38,{type:'video'});add('Shorter meeting',82,m.summaryY+73,38,38,{type:'duration',delta:-15});add('Longer meeting',218,m.summaryY+73,38,38,{type:'duration',delta:15});add('Book local demonstration',556,m.summaryY+73,96,38,{type:'book'},!State.ready(s));return out;}
const STILLS={initial:0,typing:3,lookup:7.5,ready:12,duration:16,conflict:20.5,late:23,selected:26};
return{W,H,FPS,DURATION,STILLS,draw,timeline,model,hitTargets,State};
});
