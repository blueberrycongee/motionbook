# Life in Weeks — recovery WIP

Uncounted motion checkpoint. The full 4,680-cell card now replays all 445 native source states with measured count values, curved fill/clear fronts, the lagging current-cell pulse, sparse trail cells, and independently drawn arrow / two-triangle drag pointers. The age control supports free dragging, keyboard adjustment, replay and reduced motion.

Run `npm start`, then open http://127.0.0.1:4173. Run `npm test` for the eleven current model and DOM-stub checks.

Complete every-frame visual review, final motion exports and independent review are still pending. The core/halo and age-label correction has now been inspected in all 445 native full-scene and detail pairs. This revision separates sparse marker highlights from the measured grid fill boundary, fixing small false bulges; 17 native-size comparisons pass. The complete final delta render, final media and independent review remain pending.

[Source](https://www.inspora.design/posts/8-9) · [Provenance and current limits](PROVENANCE.md)
