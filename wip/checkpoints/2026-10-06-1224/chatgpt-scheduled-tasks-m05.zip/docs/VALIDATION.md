# Validation

## Passed

- 28 Node tests of the actual independent scheduling model and UI controller.
- Full controller workflow: create, edit, schedule/time-zone changes, pause/resume, run simulation, result history, cancel-delete and confirm-delete.
- Cancellation and interrupted-save guards; duplicate-run idempotency; deletion cannot resurrect a finishing run.
- IANA time-zone conversion, daylight-saving gaps and overlaps, weekdays, monthly day 31, one-time bounds and repeat end dates.
- Search/filter composition, storage round-trip and failure handling, share snapshot isolation, HTML escaping and supported RRULE validation.
- JavaScript syntax checks.
- Offline visual inspection of list, task editor, new-task form, scrolled run history, run result, menus and delete confirmation.
- GIF/MP4 encoding, dimensions, duration and frame count are checked using ffprobe after encoding.

## Not verified

- Browser rendering, native controls, browser event wiring, actual CSS animations, browser keyboard/focus behavior and mobile layout. A normal local server startup succeeded, but an HTTP request from another tool process could not connect in this environment. Earlier Chromium operation was blocked in the cloud environment; no flags, alternate browser, or permission bypass was used.
- Native macOS runtime and exact pixel parity. The macOS installer was statically inspected on Linux, never launched.
- Real ChatGPT server execution, model inference, background scheduling, notifications, permissions, connected apps and sharing services.

The runnable `scripts/capture-browser.mjs` is provided for an environment that permits ordinary Playwright Chromium launch. It uses a fresh local demo context and does not touch a user's ChatGPT account. It was not run here and is not counted as passing validation.

## Preview method

`artifacts/scheduled-workflow.gif` and `.mp4` are 35-second 1280 × 840 offline SVG/Sharp renders sampled at 15 fps. They use snapshots of the implemented JavaScript controller/model and independently authored vector geometry; they are not screen recordings or browser captures. Cursor motion and panel/menu transitions are presentation approximations rather than measurements of the original app. No labels, watermark, original reference screenshot, installer asset or copyrighted application source is embedded in the preview.

The renderer is a separate deterministic presentation of the interface. Passing its visual review does not establish that the browser CSS has identical geometry. This distinction is retained in the README and delivery notes.

## Deeper revision status

The earlier 28-test / 35-second preview description above records the initial study. The current correction revision has 40 passing Node tests, including DOM reconciliation, actual app-adapter event dispatch, tooltip timer behavior and a numerically cross-checked spring equation.

Current primary media are `artifacts/revised-motion/scheduled-motion-detail-60fps.mp4` (18 s, 60 fps, 1080 frames) and `scheduled-motion-detail.gif` (18 s, 50 fps, 900 frames), both 1280 × 840. Their shared menu curves and state snapshots are reproducible from the renderer. GIF timing is intentionally uniform 20 ms. The movie does not silently add row-filtering springs: the observed spring applies to page-content position, not individual task rows.

A supported cloud-browser attempt to open the local server was blocked with `net::ERR_BLOCKED_BY_CLIENT`. This is a current observed blocker, not merely an inherited report. No browser security configuration, proxy bypass or alternate transport was attempted.

DOM tests use LinkeDOM and therefore verify event wiring and node preservation, not computed layout, native controls, pixel parity, actual browser focus or GPU animation. Main publication remains held, and the user's exact account-selected editor presentation is pending a screenshot/recording.
