import { MOTION, layoutKeyframes } from "./motion-spec.mjs";
const key = (node) =>
  node.nodeType === 1
    ? node.getAttribute("data-key") ||
      node.id ||
      (node.getAttribute("name") ? "field:" + node.getAttribute("name") : null)
    : null;
const compatible = (a, b) =>
  a &&
  a.nodeType === b.nodeType &&
  (a.nodeType !== 1 || (a.tagName === b.tagName && key(a) === key(b)));
function attrs(node, next) {
  for (const attr of [...node.attributes])
    if (!next.hasAttribute(attr.name) && attr.name !== "style")
      node.removeAttribute(attr.name);
  for (const attr of [...next.attributes])
    if (node.getAttribute(attr.name) !== attr.value)
      node.setAttribute(attr.name, attr.value);
  if (node.tagName === "INPUT") {
    if (node.value !== next.value) node.value = next.value;
    node.checked = next.checked;
  }
  if (node.tagName === "TEXTAREA" && node.value !== next.textContent)
    node.value = next.textContent;
}
export class DomRenderer {
  constructor(
    root,
    { motion = true, schedule = (fn, ms) => setTimeout(fn, ms) } = {},
  ) {
    this.root = root;
    this.motion = motion;
    this.schedule = schedule;
    this.exiting = new WeakSet();
  }
  remove(node) {
    if (
      this.motion &&
      node.nodeType === 1 &&
      (node.matches(".popover") || node.matches(".modal-backdrop"))
    ) {
      this.exiting.add(node);
      node.classList.add("exiting");
      node.setAttribute("aria-hidden", "true");
      node.setAttribute("inert", "");
      this.schedule(() => node.remove(), MOTION.menu.exitMs);
      return;
    }
    node.remove();
  }
  patch(node, next) {
    if (node.nodeType === 3) {
      if (node.nodeValue !== next.nodeValue) node.nodeValue = next.nodeValue;
      return;
    }
    if (node.nodeType !== 1) return;
    attrs(node, next);
    if (node.tagName !== "TEXTAREA") this.children(node, next);
    if (node.tagName === "SELECT") {
      const chosen = next.querySelector("option[selected]");
      if (chosen)
        for (const option of node.querySelectorAll("option"))
          option.selected = option.value === chosen.value;
    }
  }
  children(parent, nextParent) {
    let cursor = parent.firstChild;
    for (const next of [...nextParent.childNodes]) {
      while (cursor && this.exiting.has(cursor)) cursor = cursor.nextSibling;
      let existing = cursor;
      if (!compatible(existing, next)) {
        const k = key(next);
        existing = k
          ? [...parent.childNodes].find(
              (n) =>
                !this.exiting.has(n) && key(n) === k && compatible(n, next),
            )
          : null;
        if (existing) parent.insertBefore(existing, cursor);
        else {
          existing = next.cloneNode(true);
          parent.insertBefore(existing, cursor);
        }
      }
      this.patch(existing, next);
      cursor = existing.nextSibling;
    }
    while (cursor) {
      const next = cursor.nextSibling;
      if (!this.exiting.has(cursor)) this.remove(cursor);
      cursor = next;
    }
  }
  render(html) {
    const previous = new Map();
    if (this.motion)
      for (const el of this.root.querySelectorAll("[data-layout]"))
        previous.set(key(el), el.getBoundingClientRect());
    const template = this.root.ownerDocument.createElement("template");
    template.innerHTML = html;
    this.children(this.root, template.content);
    if (this.motion)
      for (const el of this.root.querySelectorAll("[data-layout]")) {
        const before = previous.get(key(el));
        if (!before) continue;
        el.getAnimations?.().forEach((a) => a.cancel());
        const after = el.getBoundingClientRect(),
          dx = before.x - after.x,
          dy = before.y - after.y;
        if (Math.abs(dx) + Math.abs(dy) > 0.5 && el.animate) {
          el.animate(layoutKeyframes(dx, dy), {
            duration: MOTION.layout.durationMs,
            easing: "linear",
          });
        }
      }
  }
}
