'use strict';
(async()=>{
 await Promise.all([400,500,600].map(w=>document.fonts.load(w+' 16px "Replica Sans"')));
 const canvas=document.getElementById('canvas'),ctx=canvas.getContext('2d'),input=document.getElementById('prompt'),controls=document.getElementById('controls'),status=document.getElementById('status'),reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 let began=performance.now(),last=began,time=0,manual=reduced?Scene.State.initial():null,key='',dragId=null;
 const current=()=>manual||Scene.timeline(time);
 function takeOver(){if(!manual)manual=Scene.State.clean(current());input.value=manual.prompt;}
 function dispatch(event){takeOver();if(event.type==='example'){event={type:'input',value:['Sync with Developer and Bengaluru tomorrow afternoon','Coffee with Developer Friday at 10am for 30 min','Focus time tomorrow morning for 2h'][event.index]};}manual=Scene.State.action(manual,event);input.value=manual.prompt;status.textContent=manual.booked?'Booked in this local demonstration':Scene.State.ready(manual)?Scene.State.title(manual)+', '+Scene.State.formatTime(manual.start):manual.prompt?'Checking availability':'Describe a meeting';key='';}
 input.addEventListener('focus',takeOver);input.addEventListener('input',()=>dispatch({type:'input',value:input.value}));input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();dispatch({type:'book'});}});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();dragId=null;dispatch({type:'reset'});}});
 function point(e){const b=canvas.getBoundingClientRect();return{x:(e.clientX-b.left)*1080/b.width,y:(e.clientY-b.top)*698/b.height};}
 function drag(e){const p=point(e),m=Scene.model(current()),x=(p.x-m.card[0])/m.scale;dispatch({type:'drag',minutes:540+(x-193)/52.7*60});}
 canvas.addEventListener('pointerdown',e=>{const p=point(e),s=current(),m=Scene.model(s),x=(p.x-m.card[0])/m.scale,y=(p.y-m.card[1])/m.scale;if(m.present&&Scene.State.ready(s)&&x>=193&&x<=668&&y>=160&&y<=206+s.guests.length*51){e.preventDefault();dragId=e.pointerId;canvas.setPointerCapture?.(dragId);drag(e);}});
 canvas.addEventListener('pointermove',e=>{if(dragId===e.pointerId)drag(e);});
 const release=e=>{if(dragId===e.pointerId){canvas.releasePointerCapture?.(dragId);dragId=null;dispatch({type:'release'});}};canvas.addEventListener('pointerup',release);canvas.addEventListener('pointercancel',release);
 function position(element,x,y,w,h){element.style.cssText=`left:${x/1080*100}%;top:${y/698*100}%;width:${w/1080*100}%;height:${h/698*100}%`;}
 function updateControls(s){const m=Scene.model(s),targets=Scene.hitTargets(s),next=JSON.stringify(targets.map(t=>[t.label,t.disabled]));if(next!==key){controls.replaceChildren();for(const t of targets){const b=document.createElement('button');b.className='hit';b.setAttribute('aria-label',t.label);b.disabled=!!t.disabled;b.addEventListener('click',()=>dispatch(t.action));controls.append(b);}key=next;}targets.forEach((t,i)=>position(controls.children[i],t.x,t.y,t.w,t.h));position(input,m.card[0]+74*m.scale,m.card[1]+18*m.scale,553*m.scale,44*m.scale);if(!manual)input.value=s.prompt;}
 function frame(now){const dt=Math.min(.1,Math.max(0,(now-last)/1000));last=now;time=(now-began)/1000;if(manual)manual=Scene.State.action(manual,{type:'tick',seconds:dt});const s=current();Scene.draw(ctx,time,{},manual);updateControls(s);requestAnimationFrame(frame);}requestAnimationFrame(frame);
 window.demo={getState:()=>Scene.State.clean(current()),dispatch,replay:()=>{manual=null;dragId=null;began=performance.now();key='';}};
})();
