(function(root,factory){if(typeof module==='object')module.exports=factory();else root.SchedulerState=factory();})(this,function(){
'use strict';
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const PEOPLE={jilles:{id:'jilles',name:'Jilles',email:'jilles@cloudflare.c...',avatar:'jilles'},harshil:{id:'harshil',name:'Harshil',email:'harshil@cloudflare...',avatar:'harshil'},hideyuki:{id:'hideyuki',name:'Hideyuki Tak...',email:'hideyuki@cloudflare...',avatar:'hideyuki'}};
function initial(){return{prompt:'',guests:[],duration:30,start:540,rawStart:540,day:1,dragging:false,booked:false,checking:0,video:true};}
function parseGuests(prompt){
 const tail=prompt.match(/\bwith\s+(.+)/i)?.[1]||'';
 return tail.split(/\s+and\s+/i).map(v=>v.trim().replace(/\s+(?:tomorrow|today|at|for|on)\b.*/i,'')).filter(v=>v.length>=2).slice(0,3).map(v=>{
  const q=v.toLowerCase(),id=q.startsWith('hi')?'hideyuki':q.startsWith('ji')?'jilles':q.startsWith('ha')?'harshil':q;
  return{id,query:v,name:v[0].toUpperCase()+v.slice(1),age:0,resolved:false};
 });
}
function suggestions(s){if(s.duration>=45)return[660,870,s.duration>=60?960:930];return s.guests.length?[540,660,720]:[540,600,660];}
function ready(s){return!!s.prompt.trim()&&s.guests.every(g=>g.resolved)&&s.checking<=0;}
function conflict(s){return s.start<855&&s.start+s.duration>750;}
function title(s){const lead=s.prompt.split(/\s+with\b/i)[0].trim();const base=lead?lead[0].toUpperCase()+lead.slice(1):'Name your event';if(!s.guests.length)return s.prompt.trim()?s.prompt[0].toUpperCase()+s.prompt.slice(1):base;return base+' with '+s.guests.map(g=>g.resolved?(PEOPLE[g.id]?.name||g.name):g.name).join(' & ');}
function clean(s){return{prompt:String(s.prompt||''),guests:(s.guests||[]).map(g=>({id:g.id,query:g.query||g.name.toLowerCase(),name:g.name,age:Number.isFinite(g.age)?g.age:g.resolved?1:0,resolved:!!g.resolved})),duration:s.duration||30,start:s.start??540,rawStart:s.rawStart??s.start??540,day:s.day??1,dragging:!!s.dragging,booked:!!s.booked,checking:s.checking||0,video:s.video!==false};}
function action(state,event){
 const s=clean(state),type=event.type;
 if(type==='reset')return initial();
 if(type==='input'){
  s.prompt=String(event.value).slice(0,120);const old=s.guests;s.guests=parseGuests(s.prompt).map(g=>{const p=old.find(p=>p.id===g.id&&p.query===g.query);return p?{...p}:g;});
  s.checking=s.guests.some(g=>!g.resolved)?.28:0;s.booked=false;s.dragging=false;return s;
 }
 if(type==='tick'){
  const dt=clamp(+event.seconds||0,0,2);let newly=false;s.guests=s.guests.map(g=>{const age=g.age+dt,resolved=age>=.55;if(resolved&&!g.resolved)newly=true;return{...g,age,resolved};});
  if(newly)s.checking=.28;else if(s.guests.every(g=>g.resolved))s.checking=Math.max(0,s.checking-dt);return s;
 }
 if(type==='duration'){
  s.duration=clamp(s.duration+(+event.delta||0),15,120);s.start=suggestions(s)[0];s.rawStart=s.start;s.booked=false;return s;
 }
 if(type==='time'||type==='drag'){
  s.rawStart=clamp(+event.minutes||540,540,1080-s.duration);s.start=clamp(Math.round(s.rawStart/15)*15,540,1080-s.duration);s.dragging=type==='drag';s.booked=false;return s;
 }
 if(type==='release'){s.dragging=false;return s;}
 if(type==='day'){s.day=clamp(s.day+(+event.delta||0),-30,30);s.booked=false;return s;}
 if(type==='video'){s.video=!s.video;s.booked=false;return s;}
 if(type==='book'){if(ready(s))s.booked=true;return s;}
 return s;
}
function formatTime(m){m=Math.round(m);const h=Math.floor(m/60)%24;return(h%12||12)+':'+String(m%60).padStart(2,'0')+' '+(h<12?'AM':'PM');}
function dateParts(s){const d=new Date(Date.UTC(2026,8,29+s.day)),weekday=d.toLocaleDateString('en-US',{weekday:'short',timeZone:'UTC'}),short=d.getUTCDate()+' '+d.toLocaleDateString('en-US',{month:'short',timeZone:'UTC'});return{heading:s.day===1?'Tomorrow':s.day===0?'Today':weekday,short,long:weekday+' '+short};}
return{PEOPLE,initial,parseGuests,suggestions,ready,conflict,title,clean,action,formatTime,dateParts};
});
