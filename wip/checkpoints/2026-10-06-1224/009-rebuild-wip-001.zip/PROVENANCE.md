# Source and rights

Creator: @fayazara. [Curator reference](https://www.inspora.design/posts/ai-scheduler). [Original post](https://x.com/fayazara/status/2104915749206896758).

Original media: https://media.inspora.design/posts/6c7fef86-3fda-4d5b-9291-e8254c52e94b.mp4. Its recovered SHA-256 is `830a0e6785eb9485efbdc0ce50f7a2e41376ee2462dc2401dab292e4406c722a`, matching the pre-loss catalog: 3340 × 2160, 1,693 native frames, 28.216667 seconds. It was recovered through normal public playback and a documented media download.

This is new reconstruction code. No prior lost implementation or old freeze was restored. UI geometry, icons and miniature portraits are independently drawn in Canvas. Original footage, photographs and reference crops remain local analysis material and are not implementation assets. No endorsement or broad license over the reference design or code is implied.

Study Sans Regular, Medium and Semibold are renamed Inter font derivatives recovered with the preceding licensed reconstruction assets. Their SIL Open Font License and attribution are retained in `assets/Inter-LICENSE.txt`; that license applies to the fonts only.

All people, lookup, calendar checking and booking in this demonstration are local reference-UI simulations. The app sends no email, creates no calendar event and uses no external AI service or API key.
