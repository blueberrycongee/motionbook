# Run and reconstruction status

Serve this directory with `python3 -m http.server 4173`. The prompt, guest lookup simulation, duration controls, suggested times, slot dragging, previous/next day, local booking and Escape reset are implemented. The recorded sequence is under reconstruction and has not passed complete visual or independent review.

Original media SHA and all 1,693 native timestamps are verified. Initial per-frame camera, card, pointer and column measurements are available. A 57-frame overview (native indices 0, 30, …, 1680), native intro frames 143, 145 and 146, and four original/reconstruction static pairs were visually inspected. This is partial source analysis, not all-frame fidelity approval. Tiny portraits are independent drawings and are still being calibrated.

Eleven tests pass: eight state tests and three tests executing the actual DOM adapter against a controlled interface. They cover guest lookup replacement/removal, local booking, duration, date/video changes, pointer drag and release, conflict recovery, Escape interruption, autoplay takeover and replay. Run `node --test tests/*.test.cjs`. Render with the pinned `@napi-rs/canvas` dependency and FFmpeg through `npm run render`; `node render.cjs --stills` exports only selected stills.

Actual browser runtime not executed in this validation; preview rendered offline from shared scene code. DOM-event adapter tests do not establish browser rendering/performance.

Final GIF/MP4, full native visual comparison, corrected text transition timing, exact bindings and independent approval remain pending. Private WIP checkpoints do not count as final gallery examples.
