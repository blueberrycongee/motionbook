# Provenance and checkpoint status

Independent reconstruction of [Life in Weeks](https://www.inspora.design/posts/8-9), attributed to [@jeetnirnejak](https://x.com/jeetnirnejak/status/2088251238530105638).

Original reference: https://media.inspora.design/posts/f50d7b71-f991-44d2-849c-c3f5e583cb05.mp4 . SHA-256 b073e02bef5203ea4a4e64ccbef6ca0f4f2f716c1d53b846be908f6000dd506e. The 1920 × 1514 video has 445 native 30 fps frames, PTS 0–14.8 seconds. Original footage and extracted images remain local analysis inputs and are not part of the package.

All UI geometry is drawn independently in SVG. Counts were measured from the source's visible counters at every native frame and reconciled with the 4,680-week total; seven ambiguous OCR readings were inspected directly. The original 026/027 local files were unavailable after recovery. This package is a new implementation; historical reviews do not validate it.

The first source frame and 20 overview frames were inspected during this rebuild. Complete every-frame visual pairing and independent final review remain pending. This checkpoint has no completed motion export and does not count as a finished example. Node checks cover only current geometry and model data; browser runtime has not been exercised. Font substitutes are licensed Inter and Geist Mono; notices are in licenses/. The source animation's font and footage license have not been independently established.

## Motion checkpoint

The current native replay uses independently drawn rounded cells with measured scalar row-front controls, current-cell positions/sizes, sparse cell-highlight opacities and pointer bounds. No source pixels are stored in those controls. The source's current-cell marker lags the displayed week counter; both trajectories are retained. The marker clearing ring, two-triangle drag pointer and all settings-card regions are included.

Ten model and DOM-stub checks pass. Twenty selected native-time scenes and enlarged current-cell / pointer comparisons have been rendered and inspected during refinement. Full every-frame review and final media exports remain pending. The 16.8-second demo adds an authored hold and crossfade reset after the 14.833-second source. Free slider interaction uses a bounded damped response; reduced motion applies immediate states. Browser execution and performance have not been tested.

The latest checkpoint uses fourteen measured row anchors and a three-parameter smooth front response. An interrupted manual drag preserves those full row profiles at the handoff. Optical title/counter sizing and the current-cell clearing halo were refined against enlarged native comparisons. A focused check of 936 saturated grid-cell centers found less than 0.1 pixel per-axis change at the 95th percentile between original frames 0 and 111; no unsupported extra grid movement was added. This narrow diagnostic is not a full-image fidelity percentage.
