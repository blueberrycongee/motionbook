import{stateAt,cell,TOTAL,stageForWeek}from'./scene.mjs';import{ROWS}from'./fronts.mjs';
const clamp=n=>Math.max(0,Math.min(TOTAL,n));
const inverseSmooth=y=>.5-Math.sin(Math.asin(Math.max(-1,Math.min(1,1-2*y)))/3);
const midpoint=q=>q[0]+q[1]/2-inverseSmooth(Math.pow(.5,1/(q[2]??1)))*q[1];
export class Controller{
 constructor(reduced=false){this.reduced=reduced;this.mode=reduced?'manual':'demo';this.resetFields();this.last=null;}
 resetFields(){this.value=1456;this.target=1456;this.velocity=0;this.marker=1456;this.markerWidth=18;this.markerHeight=18;this.front=ROWS.map(()=>27.5);this.soft=ROWS.map(()=>.5);this.gamma=ROWS.map(()=>1);}
 setAge(age,now,observed=stateAt(0)){
  if(this.mode==='demo'){const s=observed.crossfade!==undefined?(observed.crossfade>.5?observed.to:observed.from):observed;this.value=s.weeks;this.velocity=0;this.marker=s.current?clamp(Math.round((s.current.x-489.968279)/10.576544)*52+Math.round((s.current.y-368.764916)/10.571365)):s.weeks;this.markerWidth=s.current?.w??18;this.markerHeight=s.current?.h??18;const profiles=ROWS.map((_,j)=>s.front?.[j]??[s.weeks/52-.5,.5,1]);this.front=profiles.map(midpoint);this.soft=profiles.map(q=>q[1]);this.gamma=profiles.map(q=>q[2]??1);}
  this.mode='manual';this.target=clamp(Number.isFinite(Number(age))?Number(age)*52:0);this.last=now;if(this.reduced){this.value=this.target;this.marker=this.target;this.velocity=0;this.front=ROWS.map(()=>this.target/52-.5);this.soft=ROWS.map(()=>.5);this.gamma=ROWS.map(()=>1);}
 }
 pose(now){
  if(this.mode==='demo')return null;let dt=Math.min(.1,Math.max(0,this.last===null?0:now-this.last));this.last=now;
  if(!this.reduced){while(dt>0){const h=Math.min(.008,dt);this.velocity+=(400*(this.target-this.value)-40*this.velocity)*h;this.value=clamp(this.value+this.velocity*h);this.marker+=(this.value-this.marker)*(1-Math.exp(-14*h));this.markerWidth+=(18-this.markerWidth)*(1-Math.exp(-10*h));this.markerHeight+=(18-this.markerHeight)*(1-Math.exp(-10*h));for(let j=0;j<ROWS.length;j++){const rate=22-14*ROWS[j]/51,targetFront=this.value/52-.5;this.front[j]+=(targetFront-this.front[j])*(1-Math.exp(-rate*h));const desired=Math.max(.5,Math.abs(this.front[j]-targetFront)*1.4+.8);this.soft[j]+=(desired-this.soft[j])*(1-Math.exp(-12*h));this.gamma[j]+=(1-this.gamma[j])*(1-Math.exp(-9*h));}dt-=h;}if(Math.abs(this.value-this.target)<.005&&Math.abs(this.velocity)<.05){this.value=this.target;this.velocity=0;}}
  const weeks=Math.round(this.value),index=Math.min(TOTAL-1,Math.max(0,Math.round(this.marker))),c=cell(index),current={...c,w:this.markerWidth,h:this.markerHeight,stage:stageForWeek(index)},front=this.reduced?undefined:this.front.map((v,j)=>{const width=this.soft[j],gamma=this.gamma[j];return[v-width/2+inverseSmooth(Math.pow(.5,1/gamma))*width,width,gamma];});return{weeks,current,front,pointer:null,trail:[],knob:{x:570+this.value/TOTAL*766,y:1156,age:Math.round(this.value/52)}};
 }
 replay(now){this.mode=this.reduced?'manual':'demo';this.resetFields();this.last=now;}
}
