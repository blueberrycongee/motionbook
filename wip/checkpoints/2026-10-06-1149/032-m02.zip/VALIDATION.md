# Run and validation

Open `index.html` for the 20-second replay. Drag the clock center, a tip or a strand to take manual control. Releasing the center lets it spring home; a detached tip can fall or snap to another anchor. Press R or the top-right control to restart. The color controls change the background.

Run `node --test test.cjs`. Eight tests cover center dragging and return, tip reassignment, long free-end simulation, clean reset, all original timestamps, the folded late release, replay-to-physics conversion and the authored loop seam.

All 1,021 recovered original frames were visually inspected. The replay uses independently fitted spline geometry, analytical anchors and an independently drawn cursor. Seventy-two frames lack a reliable bright cursor core, so those cursor positions are interpolated between observed neighbors. The final portion after the recorded sequence is an authored return to the initial anchor assignment.

This source-only milestone precedes the complete replica-frame visual audit, final GIF/MP4 export and independent fidelity approval. Model tests and offline SVG rasters do not establish browser execution; actual browser runtime remains unverified. Curve endpoints, cursor occlusion/blur and fine material/type details remain review targets.
