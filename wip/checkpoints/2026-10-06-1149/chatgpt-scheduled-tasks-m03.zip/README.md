# ChatGPT · Scheduled tasks

Independent reconstruction of the Scheduled interface in ChatGPT 26.930.61225 (build 13232), inspected from the official macOS installer on October 6, 2026. No account access or proprietary application code is required.

## Visual index

![Scheduled task workflow](artifacts/scheduled-workflow.gif)

- [Full workflow MP4](artifacts/scheduled-workflow.mp4)
- [List](artifacts/view-0.png) · [Task editor](artifacts/view-54.png) · [New task](artifacts/view-206.png) · [Run history](artifacts/view-356.png) · [Delete confirmation](artifacts/view-443.png)

These are clean 35-second offline state renders, not browser or native application recordings. The sequence edits a task and its time zone, creates a recurring task, pauses and resumes it, previews a run and its history, then cancels and confirms deletion.

## Run

```sh
npm start
# Open http://127.0.0.1:4173
```

Runtime UI uses native browser ES modules, HTML and CSS, with no package install required. `?demo` uses isolated, deterministic data and exposes a capture controller. Normal mode saves only this demo's tasks under its own localStorage key.

```sh
npm test
npm install
npm run render
```

## Covered interactions

- Create manually or from suggestions; edit title and instructions
- One-time, hourly, daily, weekdays, weekly, monthly, annual and selected-day schedules
- Time, IANA time zone, end date, supported advanced RRULE editing
- Search and All/Active/Paused/Completed filters
- Row hover controls; pause/resume; Run now and save-before-run
- Previous runs, unread state, result view, pagination
- Delete confirmation; Cancel and unsaved-change confirmation
- Local share snapshot links without result history
- Keyboard shortcuts, focus states, modal focus trap, responsive panel and reduced motion

## Scope and verification

All data and execution are local simulation. Run now produces a clearly identified example result; it does not call an AI model or run a task in the background. Sharing creates a URL for this local demo, not a ChatGPT share link. The time-zone control and supported RRULE subset are independent reconstruction choices. Full server permissions, model routing, connected apps, notifications and team ownership are outside this client-only study.

Twenty-eight Node tests pass. Browser/native macOS checks were not run to completion; cloud Chromium operation was blocked and no workaround was used. Offline previews are not browser screenshots or native app recordings. See [evidence and boundaries](docs/EVIDENCE.md), [validation](docs/VALIDATION.md), and [rights](LICENSE.md).
