# Revision after first fidelity review

The initial M03 offline preview was a preliminary reconstruction and did not match several important contracts. It must not be described as faithful to the user's currently enabled interface.

## Confirmed corrections

- Replaced whole-root HTML replacement with keyed DOM reconciliation. Title/prompt input nodes, the detail panel and surviving task rows now preserve identity while editing. This prevents per-keystroke entry-animation replay and unwanted focus/scroll resets.
- Desktop typography is distinguished from browser typography: 14/12/16 px versus 16/14/18 px for base/small/large. The original 23 px task title was wrong for both profiles.
- Default page content uses the 48 rem content token. Original 1000 px content was an unsupported guess.
- Row second line shows schedule and relative next-run information. Prompt excerpts were incorrect.
- Leading status control handles pause/resume. Overflow appears on row hover/focus and persists while open. Right-side Run/Pause/Edit controls from M03 were removed from this row contract.
- Row dividers and selected/paused states follow observed selectors.
- Create has the observed split-control structure. Server-backed Create with ChatGPT remains disabled in this local reconstruction, with manual setup available. No real conversation or task is launched.
- Cloud detail time zone is a read-only value. The invented editor dropdown was removed. The model still understands IANA time zones for correct local schedule calculations.
- Unchanged cloud editor has no permanent Run now footer. Changed drafts show Save/Cancel; Run now remains a menu action.
- Menus use source-observed 150 ms entry and 100 ms exit, scale 0.95↔1, and exact entry/exit cubic-bezier constants. Exit DOM is retained until its transition ends.
- Shared layout response uses the source-observed 500 ms / 0.1 bounce contract. Its zero-velocity oscillator was independently derived in closed form from the inspected solver equation rather than copied.
- Restored the exact pending navigation target after an unsaved-change confirmation, including a selected suggestion template.
- Added before-unload protection, source-informed main-page dismissal boundaries, a source-shaped spinner, and DOM-backed event-adapter tests.

## Evidence and unresolved branches

`evidence/interaction-contracts.json` records 26 component/CSS contracts with original module names, SHA-256 fingerprints and UTF-8 byte offsets. Proprietary source is not included.

The public installer contains compact desktop, browser, side-panel, summary-panel and centered configuration-dialog paths. Static presence does not identify the feature flags enabled for the user. A current user screenshot or short recording is required to choose their exact presentation. The code does not infer account flags from the app version.

The verified common contracts are being corrected now. Branch-specific dimensions, presentation and focus differences remain explicitly separated. The compact side-panel prompt and the centered configuration editor's large prompt are distinct layouts, not interchangeable evidence.

## Verification boundary

37 Node tests pass with LinkeDOM installed, including five DOM/event-adapter checks. DOM-backed tests do not prove browser layout or real CSS animation. A normal local HTTP server starts, but the supported cloud browser refused the localhost preview with `net::ERR_BLOCKED_BY_CLIENT`; no security flags, alternate transport or bypass were used.

A new 60 fps preview is in progress. The initial 15 fps media remain preliminary and should not be used to judge the revised motion implementation.
