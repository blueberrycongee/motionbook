import test from "node:test";
import assert from "node:assert/strict";
import {
  MOTION,
  menuTransform,
  cubicBezierAt,
  layoutProgress,
  layoutKeyframes,
} from "../src/motion-spec.mjs";
test("menu entrance and exit match source timings and endpoint transforms", () => {
  assert.equal(MOTION.menu.enterMs, 150);
  assert.equal(MOTION.menu.exitMs, 100);
  assert.deepEqual(menuTransform(0), { opacity: 0, scale: 0.95 });
  assert.deepEqual(menuTransform(150), { opacity: 1, scale: 1 });
  assert.deepEqual(menuTransform(0, false), { opacity: 1, scale: 1 });
  assert.deepEqual(menuTransform(100, false), { opacity: 0, scale: 0.95 });
});
test("source enter curve advances quickly without substituting a linear fade", () => {
  const y = cubicBezierAt(0.5, [0.19, 1, 0.22, 1]);
  assert.ok(y > 0.95 && y < 1);
  assert.equal(cubicBezierAt(0, [0.19, 1, 0.22, 1]), 0);
  assert.equal(cubicBezierAt(1, [0.19, 1, 0.22, 1]), 1);
});
test("layout shared timeline is continuous, settled and deterministic", () => {
  assert.equal(layoutProgress(0), 0);
  assert.equal(layoutProgress(500), 1);
  const frames = layoutKeyframes(100, 30);
  assert.equal(frames.length, 31);
  assert.equal(frames[0].transform, "translate(100px,30px)");
  assert.equal(frames.at(-1).transform, "translate(0px,0px)");
});
