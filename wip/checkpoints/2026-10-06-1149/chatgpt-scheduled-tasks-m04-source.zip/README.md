# Scheduled source correction checkpoint

This is the source-only checkpoint for the deeper fidelity revision. Main publication is on hold. It contains a runnable local UI, evidence matrix and 37 passing Node/DOM tests.

Run `npm start` for the UI. Install dev dependencies before `npm test` to include DOM tests. No real ChatGPT task or conversation is accessed.

See docs/REVISION-NOTES.md and evidence/interaction-contracts.json. Revised media are still in progress; previous M03 previews are preliminary.
