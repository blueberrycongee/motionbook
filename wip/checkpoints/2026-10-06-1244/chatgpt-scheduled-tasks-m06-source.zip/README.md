# ChatGPT · Scheduled tasks study

Independent client reconstruction, based on static inspection of the official ChatGPT macOS 26.930.61225 installer (build 13232). The first preview was preliminary; this revision corrects specific source-confirmed layout and interaction mismatches.

## Confirmed target

The user confirmed the native Automation manager as their screen on 2026-10-06. This implementation targets `AutomationsLayoutPage` only. The account-dependent ScheduledLanding and browser-only Work views are documented separately and are not mixed into this UI. See [route decision](docs/ACTIVE-BRANCH.md).

## Revised visual index

![Revised Scheduled microinteractions](artifacts/revised-motion/scheduled-motion-detail.gif)

- [60 fps MP4](artifacts/revised-motion/scheduled-motion-detail-60fps.mp4)
- [List](artifacts/revised-motion/detail-0.png) · [Menu](artifacts/revised-motion/detail-249.png)

The revised 18-second clip covers leading status hover/tooltip, pause/resume, overflow-menu entry and exit, run loading, split Create, filtering and search. MP4: 60 fps; GIF: uniform 50 fps because GIF stores frame delays in centiseconds.

These are offline SVG/Sharp renders driven by the implemented state and shared motion contracts. They are not browser screenshots or native recordings. The target is now confirmed. These existing media predate the latest detail-panel corrections; a new full native workflow preview is pending. Main publication remains held for independent review.

## Run and test

```sh
npm start
# Open http://127.0.0.1:4173

npm install
npm test
npm run render
```

The actual UI uses native ES modules and needs no dependency installation to run. Install dev dependencies to include all DOM tests and render media. `?demo` uses isolated deterministic data; normal mode saves only this demo's state in its own localStorage key.

## Source-confirmed corrections

- Desktop typography and 48 rem content width
- Schedule/next-run row metadata, row dividers and leading pause/resume control
- Hover/focus overflow action visibility and correct row-menu scope
- Split Create control and read-only cloud time zone
- Keyed DOM reconciliation that preserves input, panel and row identities
- 150 ms / 100 ms menu entry/exit with source cubic-bezier curves and scale 0.95↔1
- Source-derived zero-velocity layout spring, 200 ms tooltip delay and 800 ms spinner rotation
- Exact pending navigation target retained through discard confirmation

See [revision notes](docs/REVISION-NOTES.md), [Interaction contracts](evidence/interaction-contracts.json), [evidence](docs/EVIDENCE.md) and [validation](docs/VALIDATION.md).

## Scope

Create/edit, local schedule calculations, pause/resume, run-history simulation, deletion confirmation and local share snapshots are implemented. No ChatGPT account, task, conversation, model, connected app, notification service or real background job is accessed. Create with ChatGPT is disabled because it requires a real conversation; manual setup remains available.

Several desktop/web/panel/dialog branches exist in the installer. Static code proves those branches are available, not which feature flags the user's account has. The native compact editor and shell width contracts are now traced. Current-account capabilities, saved width and native visual parity remain unverified. Custom RRULE handling supports a documented subset; it is not a replacement for the service scheduler.

64 Node tests pass, including DOM-backed event/identity tests. The supported cloud-browser preview route returned `net::ERR_BLOCKED_BY_CLIENT`; no bypass was used. Browser layout and native macOS runtime are not verified.

## Current source checkpoint

The editor now distinguishes existing local tasks (600 ms debounce autosave, flush before navigation) from cloud tasks (explicit Save/Cancel). New manual drafts remain explicit Create. The compact prompt is 16 px padded with a 64 px minimum, not the larger configuration dialog. The shell pane uses a 600 px fallback, source width spring, pointer resizing, 10 px keyboard resizing and Home/End limits. All persisted state belongs to the independent demo. These changes are not yet reflected in the older linked movie.
