# Elastic String Clock

[Demo](index.html) · [Source](SOURCE.md) · [Run & validation](VALIDATION.md) · [Status](STATUS.md) · [Rights](RIGHTS.md)
