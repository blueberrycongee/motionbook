# Rights

The reference license is unspecified. Original footage and decoded frames are analysis-only. The SVG geometry, cursor, spline rendering, JavaScript and interactive controller are independently authored. Source links are attribution, not a license grant. No blanket license is asserted for the referenced design.

Inter Regular, Medium, SemiBold and Bold are retained from the earlier authorized asset set under SIL Open Font License 1.1. The license is bundled as `assets/Inter-LICENSE.txt`; the official font project is https://rsms.me/inter/. Font selection follows visual comparison and is not confirmed by the reference creator.
