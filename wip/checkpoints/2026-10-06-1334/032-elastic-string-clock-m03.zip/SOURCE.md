# Reference

[Inspora Watchface](https://www.inspora.design/posts/1-39) · [Original post by @itshassco](https://x.com/itshassco/status/2091467742209552818)

Original footage: https://media.inspora.design/posts/2710bcba-9b93-4f43-b2d4-5b101647a1a7.mp4

SHA-256: `56d32ae6dab9a5b6f0eab26df1f235ac77549f3ee351fa6b895bfd65884810e7`. The recovered original matches the earlier verified hash: 3452 × 2160, 1,021 native frames, PTS 0–17 seconds and container duration 17.066667 seconds. All 1,021 recovered frames were freshly inspected on 2026-10-06.

Strings attach to a central clock hub. The hub springs back after dragging, free endpoints can fall and snap into different anchors, and plucked strands carry traveling waves. The recorded sequence reassigns the black hour strand to the moving seconds anchor, then puts the red strand on the hour anchor. The final anchor assignment differs from the opening state.

The implementation uses independently authored SVG controls, dial, cursor and spline strokes, plus a separate interactive Verlet model. Measured centerline and anchor coordinates describe the replay geometry. No source pixels or source code are part of the implementation.
