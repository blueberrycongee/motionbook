# Run and validation

Open `index.html` for the 20-second replay. Drag the clock center, a tip or a strand to take manual control. Releasing the center lets it spring home; a detached tip can fall or snap to another anchor. Press R or the top-right control to restart. The color controls change the background.

Run `node --test test.cjs`. Eight tests cover center dragging and return, tip reassignment, long free-end simulation, clean reset, all original timestamps, the folded late release, replay-to-physics conversion and the authored loop seam.

All 1,021 recovered original frames and all 1,021 first-candidate full-frame pairs were visually inspected. All 179 authored closing states of that candidate were inspected too. That pass exposed release-hub and cursor/strand defects. This revision uses fitted cursor position, scale and directional blur at every native timestamp, corrected hub positions, and independently drawn smooth connectors at short occlusions. Short isolated pointer-outline fragments are excluded from the strand geometry.

The complete revised sequence is being rendered for another full visual pass. Focused comparisons are evidence for the specific corrections; they do not replace that pass. Final GIF/MP4 export and independent fidelity approval remain pending.

Model tests and offline SVG rasters do not establish browser execution. Actual browser runtime remains unverified. The portion after the source ends is an authored return to the initial anchor assignment. Fine curve joins, cursor contours and shadows, antialiasing and typography still require final visual judgment. No pixel identity or fidelity percentage is claimed.
