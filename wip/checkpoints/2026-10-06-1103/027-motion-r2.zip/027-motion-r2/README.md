# Life in Weeks — recovery WIP

Uncounted motion checkpoint. The full 4,680-cell card now replays all 445 native source states with measured count values, curved fill/clear fronts, the lagging current-cell pulse, sparse trail cells, and independently drawn arrow / two-triangle drag pointers. The age control supports free dragging, keyboard adjustment, replay and reduced motion.

Run `npm start`, then open http://127.0.0.1:4173. Run `npm test` for the nine current model and DOM-stub checks.

Complete every-frame visual review, final motion exports and independent review are still pending. Curve and optical details are being refined.

[Source](https://www.inspora.design/posts/8-9) · [Provenance and current limits](PROVENANCE.md)
