# Source checkpoint004

The registry now contains27 recovered/discovered references and assigns Minimap to037. Graph Slider is fully inspected across all552 original frames, with all sweeps and the final hold recorded. It remains unassigned. Fractional Slider is also fully reviewed and unassigned.

Model Router is only partially reviewed: native frames0–119 and a full-resolution frame0, plus a separately labeled sparse overview. Frames120–1141 remain unreviewed. Its complete native timestamps are preserved, without implying full visual coverage.

Ringwriter’s486frame original was recovered and probed. Fresh native visual review has not begun; earlier lost-workspace inspection is historical.

No original source video, image, crop or page HTML is included. These are provenance/review records, not completed replicas.
