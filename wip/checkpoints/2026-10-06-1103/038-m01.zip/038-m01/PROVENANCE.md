# Provenance

- [Fractional Slider](https://rauno.me/craft/fractional-slider), Rauno Freiberg.
- Author: https://x.com/raunofreiberg
- Primary footage: https://cdn.rauno.me/fractional-slider.mp4#t=0.01
- SHA-256: `d44f6f9e56f7f5dc974576acd4853176f078f1000347ad810e45bb7769d3ea1c`
- Original canvas: 1344 × 460; 360 native frames over 6 seconds.

All ruler marks, labels, fade, selection range, cursor and press rings are independently drawn vectors. No source screenshots, extracted pixel assets or original footage are embedded or redistributed. Inter is a licensed SIL OFL substitute; see assets/Inter-LICENSE.txt.

The reference shows signed ruler movement, a −90 endpoint hold, a positive sweep, and a late return to zero with two press indicators. The exact input driving the stationary-pointer scroll segment and exact reset gesture are not verified. Live wheel and double-click reset are independently supplied demonstration controls.
