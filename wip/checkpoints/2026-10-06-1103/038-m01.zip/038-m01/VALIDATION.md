# Run and validation

`npm start` serves `http://localhost:8038`. Drag, wheel or use arrow keys to adjust the ruler; Shift makes wheel/key changes finer. Reset/Home returns to zero. The demo also offers double-click reset. Replay/timeline follow the complete measured native sequence once the trace is ready.

`npm test` checks signed drag, endpoint bounds, fine control, reset and vector-only rendering. Model tests and offline previews are not browser execution. Full fidelity review is pending.
