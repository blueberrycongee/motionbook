(function(root){root.RulerTrace=null;})(globalThis);
