# Fractional Slider

[Interactive demo](index.html) · [Original reference](https://rauno.me/craft/fractional-slider)

[Provenance](PROVENANCE.md) · [Run and validation](VALIDATION.md) · [Status](STATUS.md)
