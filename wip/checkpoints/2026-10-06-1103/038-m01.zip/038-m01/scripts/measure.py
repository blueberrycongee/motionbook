"""Extract numeric ruler phase/range, cursor and rings at all native timestamps."""
from pathlib import Path
from PIL import Image,ImageOps,ImageEnhance
from scipy.ndimage import label,find_objects
import numpy as np,json,subprocess,io,csv,concurrent.futures,collections
R=Path(__file__).resolve().parents[1];P=R.parents[1]/'sources/native-audit/rauno-fractional-slider';pts=json.load(open(P/'pts.json'))
def measure(i):
 im=Image.open(P/'frames'/f'{i+1:05}.png').convert('RGB');a=np.asarray(im).astype(float)
 v=np.median(a[217:224].max(2),axis=0)-25; mask=v>45;xs=np.where(mask)[0];groups=np.split(xs,np.where(np.diff(xs)>1)[0]+1);major=[]
 for g in groups:
  if 1<=len(g)<=7:major.append(float(np.sum(g*np.maximum(v[g],0))/np.maximum(v[g],0).sum())+.5)
 crop=im.crop((140,160,1204,198)).convert('L');crop=ImageOps.invert(ImageEnhance.Contrast(crop).enhance(2)).resize((2128,76));buf=io.BytesIO();crop.save(buf,format='PNG');p=subprocess.run(['tesseract','stdin','stdout','--psm','6','-c','tessedit_char_whitelist=-0123456789','tsv'],input=buf.getvalue(),stdout=subprocess.PIPE,stderr=subprocess.DEVNULL);tokens=[];offsets=[]
 for x in csv.DictReader(io.StringIO(p.stdout.decode()),delimiter='\t'):
  s=x.get('text','').strip()
  try:val=int(s)
  except:continue
  if val%5 or abs(val)>90:continue
  center=140+(float(x['left'])+float(x['width'])/2)/2
  if not major:continue
  tick=min(major,key=lambda z:abs(z-center))
  if abs(tick-center)<30:offsets.append(tick-672.5-15*val);tokens.append([val,center,tick])
 offset=None
 if offsets:
  bins=collections.Counter(round(x/5)*5 for x in offsets);best=bins.most_common(1)[0][0];vals=[x for x in offsets if abs(x-best)<4];offset=float(np.median(vals)) if vals else None
 # The resize cursor is the only white connected shape below the ruler.
 m=(a[:,:,0]>150)&(a[:,:,1]>150)&(a[:,:,2]>150);m[:260]=False;m[275:293,662:682]=False;l,n=label(m,np.ones((3,3)));candidates=[]
 for k,sl in enumerate(find_objects(l)):
  if sl:
   y,x=sl;w=x.stop-x.start;h=y.stop-y.start;c=int((l[sl]==k+1).sum())
   if 5<w<45 and 5<h<45:candidates.append((c,x.start,y.start,w,h))
 cursor=None
 if candidates:
  c,x,y,w,h=max(candidates);cursor={'x':x+w/2,'y':y+h/2,'kind':'resize' if w>=h else 'arrow','w':w,'h':h}
 # Blue selection extent is independent of ruler spring translation.
 blue=(a[230:245,:,2]-a[230:245,:,0]).mean(0); bx=np.where(blue>30)[0]; selected=None
 if offset is not None and len(bx):
  lo=round((float(bx.min())-672.5-offset)/15);hi=round((float(bx.max())-672.5-offset)/15);selected=[min(0,lo),max(0,hi)]
 return {'frame':i,'t':float(pts[i]['best_effort_timestamp_time']),'offset':round(offset,4) if offset is not None else None,'selected':selected,'cursor':cursor,'major':major,'ocr_tokens':tokens}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(measure,range(360)))
(R/'evidence/measurements.json').write_text(json.dumps(rows,separators=(',',':'))+'\n');(R/'evidence/native-timestamps.json').write_text(json.dumps([x['t'] for x in rows],separators=(',',':'))+'\n');print('Measured',len(rows),'frames; missing offsets:',[x['frame'] for x in rows if x['offset'] is None])
