# WIP 038

Early recoverable source checkpoint. Independent live signed ruler, finite −90…90 range, drag/fine wheel controls and reset are implemented. Native 360-frame measurement, complete clean media, full-frame comparison and independent review are in progress. Browser execution is unverified. Keep on private WIP only.
