# Run and validation

Run `npm start` and open port 8030 in a permitted browser. The page has no remote runtime dependency. Drag the example file and flick it toward the bin, or drop it inside. A miss increments the counter and returns the file. Enter or Space on the file deletes the example; Undo restores it. Escape or pointer cancellation releases a drag. Replay restores the recorded sequence. Reduced-motion mode starts paused and resolves a live deletion without animated travel.

The controls affect only the demo's internal state. Live toss physics are independently authored. The reference shows two recorded attempts and an Undo button, but does not show Undo being used.

## Reference coverage

The original reference is 1920 × 1360 with 282 actual native frames at 30 fps. Every original frame was inspected against the replica, with enlarged checks of the document-to-ball transition, both tosses, rim occlusion, the miss/return, bin deformation and the final toast. Exact source timestamps and hashes are recorded in `validation/frame-bindings.json`. Reference media and comparison crops remain outside this distributable package.

The first attempt crumples at frame 38, misses the right rim at 50–57, updates the miss caption at 78, and unfolds back to a document at 109. The second starts dragging at 181, crumples at 198, catches the rim at 217–224, then changes to the deletion toast at 243–249. Visible positions, scale, rotation, opacity and blur were measured against the original native frames. These measurements are optical fits to independently drawn assets; they do not claim to recover the original renderer's 3D state.

The preview preserves all 282 original frame times and adds 30 authored return frames. The return first fades the toast, expands the blank card, and then reveals the initial contents. This avoids drawing title or footer outside the expanding card. The complete preview is 312 frames / 10.4 seconds. All authored return states were also inspected. The exported GIF is generated directly from the independent PNG sequence.

## Checks

- `npm test`: nine Node tests cover all observed states, direct drop, miss/return, keyboard deletion, reset, loop-time wrapping, pointer cancellation, Replay during a drag, repeated keyboard action and reduced motion. DOM tests use a stub; they are not browser tests.
- `node scripts/verify-raster.cjs`: fresh offline RGBA checks across transition boundaries and every authored tail state. Add `--all` to verify the complete sequence. The script requires the declared Sharp development dependency.
- `node scripts/render-sequence.cjs <empty-output-folder>`: regenerate all 312 full-resolution PNG states from the authored scene.
- `python3 scripts/export.py <frame-folder> <new-media-folder>`: encode MP4 and GIF using FFmpeg, with at most two encoder threads.
- `node render.cjs <seconds> <output.png>`: render one offline SVG still.

The frame bindings, media probes, loop check, self-review record and immutable file manifest provide the specific completed checks. The final package is frozen for independent review before gallery publication.

## Runtime and fidelity limits

Browser execution has not been validated. Previously denied local Chromium launch and local-site access were respected. Offline SVG rendering and mocked DOM tests are recorded separately from browser runtime.

The bin, folded document, paper ball, smoke wisps and cursors are independently drawn SVG artwork. Fine paper crease silhouettes and their changing surface shading differ from the reference's apparent 3D paper; fine cursor contours, compression texture, antialiasing and exact font contours also differ. The native-size comparison checks retain these limits without claiming pixel identity or an unmeasured fidelity percentage. The new source is a reconstruction made after a workspace recovery, not a restored copy of the earlier lost work.
