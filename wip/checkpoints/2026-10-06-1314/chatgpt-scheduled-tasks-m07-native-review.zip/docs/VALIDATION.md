# Validation — native Automation revision

## Passed

- 70 Node tests; zero failures, zero skips with development dependencies available.
- Native routing/platform fixture combinations, without accessing account configuration.
- Model/controller workflows: create, edit, local autosave, cloud save, schedules, pause/resume, simulation, history, cancel/delete and share-snapshot isolation.
- 600 ms autosave debounce, flush-before-navigation, invalid draft guard, newer typing during a pending save, interrupted saves and duplicate run protection.
- Keyed DOM identity; app input/click wiring; custom select choices; source tooltip timing; modal/menu layering and native pane shell retention.
- Pointer/keyboard pane sizing math; spring and cubic-bezier numeric samples.
- IANA time zones, DST gaps/overlaps, monthly boundaries, end dates, supported RRULE validation and HTML escaping.
- Six latest offline keyframes inspected for layout and clean presentation, plus representative list/menu/pane frames. No auxiliary labels or watermarks.
- ffprobe verifies 1280 × 840, 34 seconds, H.264 60 fps / 2040 frames and GIF 50 fps / 1700 frames.

## Explicitly not verified

- Native macOS app execution, actual account flags/capabilities or saved shell width.
- Browser layout, computed CSS, native date/time controls, actual focus ring behavior, GPU/compositor animation and mobile layout.
- Real AI inference, task scheduler, notification service, connected projects/models, conversation navigation or sharing service.

A supported cloud-browser opening of the local demo URL returned `net::ERR_BLOCKED_BY_CLIENT`. No security flags, proxy, alternate transport or permission bypass was used. The optional `scripts/capture-browser.mjs` recipe was updated but was not run here.

DOM tests use LinkeDOM and do not establish browser pixel parity. Media use an independent SVG geometry renderer fed by the same controller snapshots and motion formulas. They are not browser captures.

## Encoding recovery

The combined high-frame-count GIF palette filter was terminated and produced an empty output. The empty GIF was detected before successful Library write; its preparation failed. Encoding now uses two bounded-memory passes, and a signaled child process is treated as failure rather than success. The final GIF passed frame-count, dimensions, duration and nonempty-file checks.
