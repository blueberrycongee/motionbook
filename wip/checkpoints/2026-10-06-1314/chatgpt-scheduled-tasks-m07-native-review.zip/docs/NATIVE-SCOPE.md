# Native target and reconstruction scope

The user explicitly confirmed Automation manager on 2026-10-06. The implementation targets native `AutomationsLayoutPage`. Browser-only Work views and ScheduledLanding remain separate research notes and fixture tests; they are not blended into this UI.

## Observed client contracts

The module/hash/byte-offset ledger records the evidence. It includes native typography, list structure, hover controls, menus, tooltip delay, spinner rate, compact editor, local autosave, cloud explicit save, deletion pending guards and app-shell pane sizing/motion. The pane fallback is 600 px, not a claim about a user's saved width. Panel progress is clamped before mapping to width. Closing clears the portal content immediately while the empty shell finishes closing.

Local Details order is Runs in → Project → Model → Reasoning. Notifications follows the frequency rows. Local Repeat exposes Hourly/Daily/Weekdays/Weekly/Custom; cloud adds Monthly. One-time/yearly model fixtures do not prove those values belong in every top-level native selector. Source-dependent account options are not inferred from missing flag evaluation.

## Independent implementation / local simulation

- The task store, IDs, history entries, sample results, network delays and persistence are independently authored local state. Nothing schedules a real job or runs a model.
- Project/model/reasoning/notification options are bounded sample capability fixtures. They do not advertise the user's actual available account choices.
- The supplied template copy and task content are sample data; exact name-and-prompt duplicates are suppressed as the client does.
- History selection displays a simple local result placeholder. The app's complete conversation renderer and thread navigation are outside this study.
- Share snapshots encode the local draft into a local URL. They are not ChatGPT sharing links or permission changes.
- RRULE conversion supports the explicitly tested subset. Complex rule semantics and all server restrictions are not reproduced.
- Native HTML date/time controls remain a reconstruction boundary. The time suggestion menu contains quarter-hour choices; custom typed times remain supported.
- Cursor travel and fixed demonstration delays are authored choreography. Observed animation contracts are reused for menu and pane transitions; the full offline renderer is not a browser-layout oracle.

## Why this is not called pixel-identical

The official macOS app was statically inspected on Linux, not executed. Its renderer bundle confirms contracts but not the user's theme, font rasterizer, stored dimensions, capabilities or compositor timing. Browser execution was blocked on the permitted route. The deliverable is a source-grounded independent study with these limits exposed, not an assertion of unobserved runtime parity.
