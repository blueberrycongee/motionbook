> Target resolved on 2026-10-06: the user explicitly confirmed Automation manager. The decision-tree findings below describe shipped selectors, not access to their account flags.

# Which Scheduled interface is actually selected?

Inspected build: ChatGPT macOS 26.930.61225 / 13232. This is a control-flow trace of the shipped entrypoints, not an inference from filenames. It does not claim access to the user's logged-in runtime.

## The actual route selector

Both `/scheduled` and `/automations` are routed through the same selector, `rbs` in `app-initial-69cd8dbddec5.js`.

The first selector value is the atom exported as `KF` by the shared bundle (local name `z0r`). It is true only when feature gate `3085093835` is true and the auth state is not a denial specifically caused by unsupported authentication. It is not a simple “browser versus desktop” check.

1. When this selector is true, `/automations` redirects to `/scheduled`.
2. If local or cloud automation capability is allowed, the normal route with this selector true loads `ScheduledLanding` from `landing-952e64804a02.js`. The center displays a clock illustration, “Schedule a task,” a short description and a “New task” action or recommendations. Selecting a task/run replaces the center with a task summary or run conversation. Task navigation lives elsewhere in the shell.
3. The landing route is intentionally bypassed by `view=manage`, shared-task links and the share-dialog path. Creation can add a separate `create-dialog` presentation on top.
4. Otherwise the route contains two complementary platform wrappers. Tracing their helper `$Na` in this exact macOS build resolves it to the compile-folded predicate `electron && true`. Therefore the browser-only wrapper around `NAa` does not render on this build. The complementary wrapper does render `AutomationsLayoutPage`.
5. The browser-only shared-code path would let `NAa` select `ScheduledTasksPage` for Work/shared links, but it is not this macOS installer's native fallback. Merely finding its lazy import was insufficient evidence. The native fallback is definitively AutomationsLayoutPage, regardless of the separate Work/Codex role selector.

For this native installer, ordinary top-level routing is narrowed to two real choices: feature 3085093835 plus supported auth enabled → ScheduledLanding; disabled → AutomationsLayoutPage. Configuration flag 4283773748 additionally changes creation/editor presentation. Normal modern landing implies configuration enabled; manage/shared query paths intentionally select the manager.

## Configuration/table versus composer

The configuration atom `jAa` is the first selector above OR feature gate `4283773748`.

In the browser-only ScheduledTasksPage branch, that atom chooses the newer searchable task-table path (`table-496b346d1e15.js`) versus the composer/list path with heading “Scheduled” and placeholder “Schedule a task.” It also changes the editor/create presentation. Therefore the configuration flag is a concrete route/layout selector, not merely unused code.

## Shipped fallback is not the signed-in user's value

- The shared feature-gate reader uses the initialized Statsig client's `getFeatureGate(...).value`. Without a client/evaluation it falls back to false; server snapshots also return false. A values-updated listener refreshes the atoms.
- The native setting declaration defaults `conversationDetailMode` to `STEPS_COMMANDS`.
- Native `getEffective()` does not blindly use that default: it first obtains identity-matched execution assignments and a published work-mode policy. `everyday` forces `STEPS_PROSE`; `coding` forces `STEPS_COMMANDS`; `preference` uses the saved preference. Missing matching assignments produce no ready effective value.
- The renderer resolves Work versus Codex from the effective prose/commands setting and, when that setting is missing, onboarding/backend role information. Non-coding roles select Work. That selector matters to the shared browser route; the compile-folded native fallback wrapper directly renders AutomationsLayoutPage.
- Native Statsig publications are kept with user/account/auth/stable identity and applied at runtime. The public installer contains this selection logic, not the user's evaluated values.

Consequently, the source-only fallback path can be established: missing gate evaluations are false and the bare setting default is commands. That does not establish the interface actually enabled after the user's account signs in. Calling the fallback “the active UI” would be incorrect.

## What the preliminary reconstruction got wrong

It started with AutomationsLayoutPage before tracing the shared route selector and compile-folded platform wrapper. The initial “Scheduled tasks” page and its later compact-list microinteraction movie demonstrate the native fallback/manager component family. They must not be presented as confirmation that the user’s remote selector is disabled or that this is their active screen.

The next faithful implementation needs either the current runtime selector values or a direct view of the user's Scheduled page. No credentials, account files or real scheduled tasks were read to obtain this report. Static inspection alone has reached the account-evaluation boundary.

See `evidence/branch-selection.json` for original module hashes and UTF-8 byte offsets. No proprietary source is embedded here.
