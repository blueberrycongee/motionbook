# Contracts of the actual ChatGPT paths

The exact macOS platform guard excludes the browser-only Work page from the native fallback. The user subsequently confirmed the native Automation manager as the target. The runnable page is AutomationsLayoutPage; alternate paths below remain research-only. The exact selection decision is in ACTIVE-BRANCH.md.

## Feature-enabled ScheduledLanding

Source: `landing-952e64804a02.js`, exported `ScheduledLanding`.

- With no selected task/run, the main shell header has no divider. The content scroll container is full height. Centered empty-state content has maximum width 46.125 rem and 44 px gaps.
- Center title is exactly “Schedule a task,” 18 px normal weight, 26 px line height, -0.025 em tracking. Description is 14 px / 20 px normal, -0.01 em tracking. It uses a clock emoji illustration above the title.
- The action area is a recommendations component. Its empty fallback is the round “New task” action; this is not evidence that every account always sees that button alone.
- New task navigates to creation query state. The router mounts the manual creation dialog above the landing view.
- Selected task IDs select cloud/local task summaries. A selected run can instead open a conversation/result view, keyed by account and selected run. Missing cloud tasks (404/410) and absent local tasks return to /scheduled. Other loading failures render Retry.
- The landing itself is not the task-list manager. Navigation/task selection is provided by the surrounding shell.

## Browser-only Work ScheduledTasksPage composer/list path

Source: `page-2e9884a85c00.js`, exported `ScheduledTasksPage`.

- Heading “Scheduled,” explanatory subtitle, Active filter initially selected. The filter offers Active/Paused/Completed. There is no All filter in this path.
- Natural-language composer is the main create affordance, using auto-single-line layout, hidden model picker, “Schedule a task” placeholder, and an account/mode-derived model. Submit is disabled while its mode is unresolved. Accepted submit navigates into the conversation.
- Content stacks composer, error/loading state and task rows with 24 px gaps. Error state has Retry. Loading reserves a minimum 160 px height and includes an accessible loading announcement.
- Active includes active tasks plus a separate group of tasks paused/completed during the last 24 hours. A local pause timestamp preserves just-paused rows before a refreshed server timestamp arrives. This intentionally differs from simple status filtering.
- The work projection in `work-view-model.mjs` implements this confirmed grouping independently, with tests. It is not yet wired into the alternate runnable page.
- A scheduled task with no future run times is treated as completed unless it is event-triggered; otherwise enabled determines active/paused.
- Row title and summary are both base-size with 24 px line height. Active title is medium weight/default tone; inactive title is tertiary. Secondary content uses a cadence/summary component, not an arbitrary prompt excerpt.
- Left status control has separate rest, whole-row hover and direct-button hover/focus-visible icon states. Status mutation has pending/disabled and loading state.
- Right actions are Edit plus overflow, revealed on hover/focus and kept visible while the menu is open. Work-origin task badge appears beside the title on row hover. Unread results can replace or supplement the leading icon according to an emoji-display gate.
- Status errors produce a failure toast; row pause/resume uses account-aware mutation handling.
- Paused and completed sections have pagination; active does not use that pagination control. Recommendations are active-filter-only and depend on fetched conversation recommendations.

## Browser-only Work configuration/table path

The same Work page switches to `table-496b346d1e15.js` when the configuration atom is enabled. It offers search, ownership scope, status and sort controls, task/next-run/schedule columns, and an Add affordance. This is a real active branch of that page, not a second independent hardcoded app.

## Account-dependent detail presentation

The Work page uses a remote layer's `enabled` parameter for latest-update presentation (fallback false), query state for editing/sharing, and capability checks. The centered editor's xwide size resolves to 680 px. The configuration editor and compact cloud side-panel are separate presentations; dimensions or focus rules from one must not be applied to the other blindly.

## Remaining uncertainty

A public installer establishes the selectors and all of these contracts. It does not supply the user's evaluated flags, effective account policy, task data or screenshot. The user has confirmed Automation manager, which resolves top-level scope. Capability/configuration subbranches and stored shell preferences remain unobserved; their fixtures must remain explicit.
