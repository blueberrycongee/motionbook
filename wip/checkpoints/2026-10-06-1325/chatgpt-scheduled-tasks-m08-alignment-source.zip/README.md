# ChatGPT · Native Automation study

Independent reconstruction of the native Automation manager the user confirmed, based on static inspection of official ChatGPT macOS 26.930.61225, build 13232. No proprietary bundle, code, fonts or reference captures are included.

## Visual index

![Native Automation workflow](artifacts/native-workflow/native-automation-workflow.gif)

[60 fps MP4](artifacts/native-workflow/native-automation-workflow-60fps.mp4) · [Local editor](artifacts/native-workflow/detail-530.png) · [Create](artifacts/native-workflow/detail-1260.png) · [Delete confirmation](artifacts/native-workflow/detail-1580.png)

The clean 34-second workflow covers the list, cloud editing and explicit save, local editing and autosave, menus, manual creation, simulated run/history, pause, deletion cancellation/confirmation, filter and search. MP4 is 60 fps; GIF is uniform 50 fps because its timestamps use centiseconds. No explanatory overlays or watermarks appear.

These are **offline SVG/Sharp renders**, driven by the implemented controller and shared motion formulas. They are not browser screenshots or native-app recordings. The native browser layout remains unverified.

## Run

```sh
npm start
# Open http://127.0.0.1:4173/?demo

npm install
npm test
npm run render
```

The UI is native ES modules and needs no installation to run. Dev dependencies enable DOM tests and media generation. Normal mode saves only this demo's local state; `?demo` uses deterministic isolated data.

## Source-derived behavior

- Desktop 14/12/16 px type tokens and 768 px default content maximum
- Compact rows with cadence/next-run text, hover/focus controls, pause/resume and overflow actions
- 150 ms menu entry / 100 ms exit, source cubic-bezier curves and 0.95↔1 scale
- Native right pane: 600 px unsaved-width fallback, 320 px minimum, 500 ms / bounce 0.1 width spring, pointer and keyboard resizing
- Compact prompt, native Details/Frequency order and conditional cloud time zone
- Existing local tasks: 600 ms debounced autosave; valid changes flush before navigation
- Existing cloud tasks: explicit Save/Cancel; new drafts: explicit Create
- Exact-name-and-prompt suggestion deduplication, pending deletion guards, Escape/outside dismissal, keyed input preservation

[Evidence ledger](evidence/interaction-contracts.json) · [Route decision](docs/ACTIVE-BRANCH.md) · [Validation](docs/VALIDATION.md) · [Scope and fidelity limits](docs/NATIVE-SCOPE.md)

## Verification and limits

77 Node tests pass, including DOM-backed event/identity checks, autosave races, interrupted navigation, schedule/DST calculations and workflow assertions. A permitted cloud-browser navigation returned `net::ERR_BLOCKED_BY_CLIENT`; no bypass was used. LinkeDOM does not verify layout, browser-native controls, focus rendering or compositor animation.

Task execution, results, project/model choices, notifications, sharing and server timing are local fixtures. No ChatGPT account or real task was accessed. History selection uses a local result placeholder rather than recreating ChatGPT's conversation renderer. Custom RRULE support is intentionally bounded. See the scope document before treating this study as a complete production client or pixel-parity claim.

## M08 alignment audit in progress

[Alignment audit](docs/ALIGNMENT-AUDIT.md) and [multi-width coordinates](evidence/alignment-coordinates.json) correct shared DOM/offline geometry. The movie above remains the immutable M07 workflow, not an M08 visual acceptance claim. A further account-dependent header/search/toolbar structure needs target confirmation before final media/promotion.
