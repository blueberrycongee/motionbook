# Native Automation alignment audit (M08)

This audit compares the independent DOM/CSS and offline renderer against statically observed native component contracts. It does not claim browser-computed or account-runtime measurements.

## Verified defects and bounded corrections

| Area | M07 defect | Source contract / M08 correction |
|---|---|---|
| Main content width | Treated 768 px as usable content | The maximum includes 20 px gutters on both sides; usable width is 728 px when unconstrained |
| Page heading | Shared the list's outer left edge | The inset heading adds another 8 px inside the common content gutter |
| Leading row control | 28 px hit box, vertically centered across both text lines | `iconMd` is 20 px; it sits in a 24 px first-line rail. Control center is row y+24, not y+32 |
| Offline leading icon | Another 4 px right of the DOM icon | SVG and DOM now use the same row left +22 px center |
| Overflow control | 32 px hit box | Native menu trigger's `md` resolves to the 28 px control-size-sm; center is 26 px from the row right edge |
| Suggestion text | 28 px icon column; schedule pushed to the far right | Same 20 px leading column as rows; cadence follows title on its baseline with an 8 px gap |
| Field values | A blanket 72% maximum and 14 px gap | Nested control uses min-width:0, flex:1, justify-end, and 12 px label/control gap |
| Form edge | Offline renderer omitted frame and group borders | 1 px pane border and 1 px group border are included before padding; label/value rails are distinct from outer card edges |
| Footer | 12 px vertical padding and oversized 36 px buttons | Native shell footer uses 20 px on all sides; cloud buttons use 28 px toolbar size and 8 px horizontal padding |
| Repeated pane transition | Reopening restarted at zero; an older timer could remove a newer pane | Starts from measured in-flight width, invalidates stale close timers, preserves shell identity |

## Shared geometry

`src/alignment-spec.mjs` supplies the coordinate formulas used by CSS variables, the offline renderer and regression fixtures. `evidence/alignment-coordinates.json` evaluates 960, 1280 and 1600 px widths, with no pane and 320/520/600 px panes.

At 1280 px, closed default-width profile:

- Outer maximum: x=256…1024 (768 px)
- Usable list/search rail: x=276…1004 (728 px)
- Inset heading: x=284
- Task title/subtitle rail: x=316
- Status-control center: x=298; y=row top+24
- Overflow-control center: x=978; y=row top+32
- Dividers: x=288…992

For a 600 px pane at the same viewport:

- Pane left=680; body/card rail=701…1260
- Nested field labels start at718; read-only value right edge=1243
- Footer right edge=1260; button bottom=820 at840 px height

These are box-coordinate derivations, not measured native glyph baselines. Font rasterization and line breaking still require an allowed real-browser/native run. The offline renderer now aligns first/second line boxes explicitly and does not estimate an inline cadence's x position by multiplying character count.

## Conditional structure still requiring target confirmation

The native Automation page also has account/configuration-dependent page layout:

- Its regular/inset profile separates search, navigation/status filter and application toolbar containers.
- Opening the detail outlet requests `headerPlacement=toolbar` for that profile.
- Another gate overrides the page to sticky/compact with a wider content limit.

The user confirmed Automation manager, which resolves the top-level route but not these evaluated subprofile values. M08 fixes the shared alignment defects without silently choosing a new account configuration. The current combined toolbar remains a reconstruction boundary; final restructuring is held until a screenshot or equivalent authorized runtime evidence establishes the actual subprofile.

M07 remains immutable. Its video has not been silently relabeled as an M08 alignment proof. No new alignment movie is promoted as final while the structural branch is unresolved.
