import {grid,visibleSlots} from './geometry.mjs';
import {glyphs,unitsPerEm} from './glyphs.mjs';
export function createRenderer(Path) {
  const paths=new Map(Object.entries(glyphs).map(([ch,g])=>[ch,new Path(g.path)]));
  return function draw(ctx,states=[]) {
    ctx.fillStyle='#1e1e1e';ctx.fillRect(0,0,grid.width,grid.height);
    ctx.fillStyle='#858585';
    for(const p of visibleSlots()) {ctx.beginPath();ctx.arc(p.x,p.y,.75,0,Math.PI*2);ctx.fill();}
    for(const s of states) {
      const g=glyphs[s.char];if(!g||!paths.has(s.char))continue;
      if(![s.x,s.y,s.rotation,s.size,s.alpha].every(Number.isFinite))throw new TypeError('Finite glyph state required');
      ctx.save();ctx.translate(s.x,s.y);ctx.rotate(s.rotation);ctx.translate(0,s.size*.32);ctx.scale(s.size/unitsPerEm,-s.size/unitsPerEm);ctx.translate(-g.advance/2,0);ctx.globalAlpha=Math.max(0,Math.min(1,s.alpha));ctx.fillStyle='#f5f5f5';ctx.fill(paths.get(s.char));ctx.restore();
    }
  };
}
