# Source and development status

Reference: https://www.inspora.design/posts/1-60 by @edo_lunardi, linked to https://x.com/edo_lunardi/status/2079129478630977948. Original media: https://media.inspora.design/posts/6d134bd8-7e48-4cba-bcd7-7d29b9357b9b.mp4.

The 1728×1728 original has 486 native frames at 60fps, ending at PTS8.083333s. Source SHA-256: cd577d97e239c866200fc574045ca60106aa85285efb498b3b06014585c69f81. All486 original frames were visually inspected in full-canvas contact sheets, supplemented by native-size keyframes and enlarged typography strips. Source footage and derived images remain outside this package.

This early checkpoint contains a measured ring grid and an independent glyph-outline drawing foundation. Its static development view is not a finished reconstruction. The original glyph sequence, scale/opacity response, phase motion, pointer interaction and native replay still need to be fitted. No replica similarity claim or browser execution claim is made.

The outline font is an OFL-licensed derivative called Replica Ring Mono. The source font is documented separately in licenses/. Original reference assets and source pixels are not included.
